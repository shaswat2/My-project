package com.estatehub.controller;

import com.estatehub.model.Property;
import com.estatehub.service.PropertyService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/api/properties")
@RequiredArgsConstructor
public class PropertyController {

    private final PropertyService service;

    @GetMapping
    public List<Property> list(
            @RequestParam(required = false) String city,
            @RequestParam(required = false) String type,
            @RequestParam(required = false) String listingType,
            @RequestParam(required = false) Integer minBedrooms,
            @RequestParam(required = false) BigDecimal minPrice,
            @RequestParam(required = false) BigDecimal maxPrice,
            @RequestParam(defaultValue = "100") int limit
    ) {
        boolean noFilters = city == null && type == null && listingType == null
                && minBedrooms == null && minPrice == null && maxPrice == null;
        return noFilters
                ? service.findAll().stream().limit(limit).toList()
                : service.search(city, type, listingType, minBedrooms, minPrice, maxPrice, limit);
    }

    @GetMapping("/featured")
    public List<Property> featured() { return service.findFeatured(); }

    @GetMapping("/{id}")
    public ResponseEntity<Property> get(@PathVariable Long id) {
        return service.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/me")
    public List<Property> myProperties() { return service.myProperties(); }

    @PostMapping
    public Property create(@RequestBody Property p) { return service.create(p); }

    @PutMapping("/{id}")
    public Property update(@PathVariable Long id, @RequestBody Property p) {
        return service.update(id, p);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
