package com.estatehub.dto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BookingRequest {
    @NotNull
    private Long propertyId;
    @NotNull
    private LocalDate checkInDate;
    private LocalDate checkOutDate;
    private String message;
}
