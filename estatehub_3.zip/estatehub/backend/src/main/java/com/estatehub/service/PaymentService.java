package com.estatehub.service;

import com.estatehub.model.Booking;
import com.estatehub.model.User;
import com.estatehub.repository.BookingRepository;
import com.estatehub.security.AuthFacade;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.UUID;

/**
 * Mock payment service for the EstateHub demo. Records a fake transaction ID and marks
 * the booking PAID. To plug in a real gateway:
 *
 * 1. Add Razorpay/Stripe SDK to pom.xml.
 * 2. Replace the body of {@link #charge(Long, String)} below with the real API call.
 * 3. Capture the real payment ID and webhook callbacks.
 *
 * The rest of the app — Booking entity, controllers, frontend — needs no changes.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class PaymentService {

    private final BookingRepository bookingRepository;
    private final AuthFacade auth;

    /**
     * Simulate payment capture. The frontend just hits this endpoint once the user
     * "completes" the mock checkout dialog. We mark the booking PAID and return the txn id.
     */
    public Booking charge(Long bookingId, String mockCardLast4) {
        User user = auth.currentUser();
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new IllegalArgumentException("Booking not found"));

        if (!booking.getGuestId().equals(user.getId())) {
            throw new SecurityException("You can only pay for your own bookings");
        }
        if (booking.getStatus() != Booking.Status.CONFIRMED) {
            throw new IllegalStateException("Booking must be confirmed by the owner before payment");
        }
        if (booking.getPaymentStatus() == Booking.PaymentStatus.PAID) {
            throw new IllegalStateException("Booking is already paid");
        }

        // ── Simulate a payment gateway call (would be Razorpay/Stripe in prod) ──
        String txnId = "MOCK_TXN_" + UUID.randomUUID().toString().replace("-", "").substring(0, 16).toUpperCase();
        log.info("Mock payment captured: booking={} txn={} card=****{}", booking.getId(), txnId, mockCardLast4);

        booking.setPaymentStatus(Booking.PaymentStatus.PAID);
        booking.setPaymentId(txnId);
        booking.setPaidAt(Instant.now());

        // Mark the booking COMPLETED for SALE flows; for RENT, owner still completes it post-tenancy
        return bookingRepository.save(booking);
    }
}
