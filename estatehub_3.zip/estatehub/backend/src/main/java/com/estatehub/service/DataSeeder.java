package com.estatehub.service;

import com.estatehub.model.Property;
import com.estatehub.model.User;
import com.estatehub.repository.PropertyRepository;
import com.estatehub.repository.UserRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ClassPathResource;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.util.List;

/**
 * On first startup:
 *  1. Seeds 3 sample owners + 1 sample guest
 *  2. Loads 100 properties from seed-properties.json and distributes them across the owners
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class DataSeeder {

    private final PropertyRepository propertyRepository;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final ObjectMapper objectMapper;

    @PostConstruct
    public void seed() {
        seedUsers();
        seedProperties();
    }

    private void seedUsers() {
        if (userRepository.count() > 0) return;

        List<User> users = List.of(
            User.builder().name("Rajesh Kumar").email("owner1@estatehub.com")
                .password(passwordEncoder.encode("password123"))
                .phone("+91 98765 11111").role(User.Role.OWNER).build(),
            User.builder().name("Priya Sharma").email("owner2@estatehub.com")
                .password(passwordEncoder.encode("password123"))
                .phone("+91 98765 22222").role(User.Role.OWNER).build(),
            User.builder().name("Anil Verma").email("owner3@estatehub.com")
                .password(passwordEncoder.encode("password123"))
                .phone("+91 98765 33333").role(User.Role.OWNER).build(),
            User.builder().name("Amit Singh").email("guest@estatehub.com")
                .password(passwordEncoder.encode("password123"))
                .phone("+91 98765 44444").role(User.Role.GUEST).build()
        );
        userRepository.saveAll(users);
        log.info("Seeded {} sample users (3 owners + 1 guest). Login: owner1@estatehub.com / password123",
                users.size());
    }

    private void seedProperties() {
        if (propertyRepository.count() > 0) return;

        // Get seeded owner IDs to assign properties to
        List<User> owners = userRepository.findAll().stream()
                .filter(u -> u.getRole() == User.Role.OWNER)
                .toList();
        if (owners.isEmpty()) {
            log.warn("No owners found, skipping property seed.");
            return;
        }

        try (InputStream is = new ClassPathResource("seed-properties.json").getInputStream()) {
            List<Property> seed = objectMapper.readValue(is, new TypeReference<>() {});

            // Distribute properties round-robin across owners
            for (int i = 0; i < seed.size(); i++) {
                seed.get(i).setOwnerId(owners.get(i % owners.size()).getId());
            }

            propertyRepository.saveAll(seed);
            log.info("Seeded {} properties across {} owners", seed.size(), owners.size());
        } catch (Exception e) {
            log.error("Failed to seed properties from JSON", e);
        }
    }
}
