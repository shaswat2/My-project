package com.estatehub.service;

import com.estatehub.dto.ChatDtos.ChatResponse;
import com.estatehub.dto.LeadRequest;
import com.estatehub.dto.ViewingRequest;
import com.estatehub.model.Property;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Rule-based chatbot for EstateHub. No external API needed.
 * Detects intent from keywords, extracts search params (city, BHK, price, type)
 * with regex, and runs the same property search the rest of the API uses.
 * Multi-step flows (lead capture, viewing scheduling) use a per-session state machine.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class ChatService {

    private final PropertyService propertyService;
    private final LeadService leadService;
    private final ViewingService viewingService;

    /** Conversational sub-flows that span multiple turns. */
    private enum Flow { LEAD_NAME, LEAD_PHONE, LEAD_REQUIREMENT,
                        VIEW_PROPERTY, VIEW_NAME, VIEW_PHONE, VIEW_DATE }

    private static class Session {
        Flow flow;
        Map<String, Object> data = new HashMap<>();
        List<Property> lastResults = List.of();
    }

    private final Map<String, Session> sessions = new ConcurrentHashMap<>();

    private static final Set<String> CITIES = Set.of(
        "mumbai", "bangalore", "bengaluru", "chennai", "hyderabad",
        "pune", "delhi", "gurgaon", "noida", "kolkata", "ahmedabad"
    );

    private static final Map<String, String> TYPE_KEYWORDS = Map.ofEntries(
        Map.entry("apartment", "APARTMENT"),
        Map.entry("apartments", "APARTMENT"),
        Map.entry("flat", "APARTMENT"),
        Map.entry("villa", "VILLA"),
        Map.entry("villas", "VILLA"),
        Map.entry("plot", "PLOT"),
        Map.entry("land", "PLOT"),
        Map.entry("house", "INDEPENDENT_HOUSE"),
        Map.entry("bungalow", "INDEPENDENT_HOUSE"),
        Map.entry("office", "COMMERCIAL"),
        Map.entry("commercial", "COMMERCIAL"),
        Map.entry("shop", "COMMERCIAL")
    );

    private static final Pattern BHK_RE   = Pattern.compile("(\\d+)\\s*(bhk|bedroom|bed|bedrooms)");
    private static final Pattern CRORE_RE = Pattern.compile("([\\d.]+)\\s*(cr|crore|crores)");
    private static final Pattern LAKH_RE  = Pattern.compile("([\\d.]+)\\s*(l|lakh|lakhs|lac)");
    private static final Pattern RAW_RE   = Pattern.compile("(?<![\\d.])(\\d{4,8})(?![\\d.])");
    private static final Pattern PROP_ID  = Pattern.compile("#?(\\d+)");
    private static final Pattern PHONE_RE = Pattern.compile("(\\+?91[\\s-]?)?[6-9]\\d{9}");

    public ChatResponse chat(String sessionId, String message) {
        Session s = sessions.computeIfAbsent(sessionId, k -> new Session());
        String text = message.trim();
        String lower = text.toLowerCase();

        // ── Continue active multi-step flow ─────────────────────────────────
        if (s.flow != null) {
            return continueFlow(s, sessionId, text);
        }

        // ── Top-level intent detection ──────────────────────────────────────
        if (matches(lower, "^(hi|hello|hey|yo|hola|namaste|good\\s+(morning|afternoon|evening))")) {
            return text(sessionId,
                "Hey! 👋 I'm Aria, your EstateHub assistant. What kind of property are you " +
                "looking for? Try things like:\n" +
                "• \"Show me 2BHK apartments in Bangalore under 1Cr\"\n" +
                "• \"Villas for rent in Mumbai\"\n" +
                "• \"Schedule a viewing\"");
        }

        if (matches(lower, "thank|thanks|appreciate|cheers")) {
            return text(sessionId, "You're welcome! Anything else I can help with? 🏡");
        }

        if (matches(lower, "help|what can you do|what do you do")) {
            return text(sessionId,
                "I can help you with:\n" +
                "🔍  Search properties — \"3BHK villa in Hyderabad under 5Cr\"\n" +
                "📋  Property details — \"Tell me about #3\"\n" +
                "📅  Schedule a viewing\n" +
                "📞  Connect you with an agent\n\n" +
                "What would you like to do?");
        }

        if (matches(lower, "schedule|book.*viewing|book.*visit|visit|tour")
                || (lower.contains("viewing") && !lower.contains("not"))) {
            return startViewingFlow(s, sessionId);
        }

        if (matches(lower, "contact|call.*me|reach.*out|talk.*to.*agent|speak.*to|connect.*me|callback")) {
            return startLeadFlow(s, sessionId);
        }

        if (matches(lower, "tell me (more )?about|details (of|about|on)|info (on|about)|property\\s*#?\\d+")) {
            return showPropertyDetail(s, sessionId, lower);
        }

        // ── Default: treat as a property search ─────────────────────────────
        return doSearch(s, sessionId, text, lower);
    }

    // ════════════════════════════════════════════════════════════════════════
    // SEARCH
    // ════════════════════════════════════════════════════════════════════════

    private ChatResponse doSearch(Session s, String sessionId, String text, String lower) {
        SearchParams p = parseSearchParams(lower);
        List<Property> results = propertyService.search(
                p.city, p.type, p.listingType, p.minBedrooms, null, p.maxPrice, 6);

        s.lastResults = results;

        if (results.isEmpty()) {
            return text(sessionId,
                "I couldn't find any properties matching that. Try widening the budget, " +
                "changing the city, or browsing all listings on the Properties page.");
        }

        StringBuilder reply = new StringBuilder("Here are " + results.size() + " ");
        if (p.listingType != null) reply.append("for ").append(p.listingType.toLowerCase()).append(" ");
        if (p.type != null) reply.append(p.type.toLowerCase().replace("_", " ")).append(" ");
        else reply.append("matching ");
        reply.append("properties");
        if (p.city != null) reply.append(" in ").append(capitalize(p.city));
        if (p.maxPrice != null) reply.append(" under ").append(formatPrice(p.maxPrice));
        reply.append(":");

        return new ChatResponse(reply.toString(), sessionId,
                List.of(Map.of("kind", "property_list", "items", results)));
    }

    private static class SearchParams {
        String city, type, listingType;
        Integer minBedrooms;
        BigDecimal maxPrice;
    }

    private SearchParams parseSearchParams(String lower) {
        SearchParams p = new SearchParams();

        // City
        for (String city : CITIES) {
            if (lower.contains(city)) {
                p.city = city.equals("bengaluru") ? "Bangalore" : capitalize(city);
                break;
            }
        }

        // Property type
        for (Map.Entry<String, String> e : TYPE_KEYWORDS.entrySet()) {
            if (lower.contains(e.getKey())) { p.type = e.getValue(); break; }
        }

        // Listing type — rent vs sale
        if (lower.contains("rent") || lower.contains("rental") || lower.contains("lease")) {
            p.listingType = "RENT";
        } else if (lower.contains("buy") || lower.contains("sale") || lower.contains("purchase") || lower.contains("sell")) {
            p.listingType = "SALE";
        }

        // BHK / bedrooms
        Matcher mBhk = BHK_RE.matcher(lower);
        if (mBhk.find()) p.minBedrooms = Integer.parseInt(mBhk.group(1));

        // Price (max budget)
        Matcher mCr = CRORE_RE.matcher(lower);
        Matcher mL  = LAKH_RE.matcher(lower);
        if (mCr.find()) {
            p.maxPrice = BigDecimal.valueOf(Double.parseDouble(mCr.group(1)) * 1_00_00_000);
        } else if (mL.find()) {
            p.maxPrice = BigDecimal.valueOf(Double.parseDouble(mL.group(1)) * 1_00_000);
        }
        return p;
    }

    // ════════════════════════════════════════════════════════════════════════
    // PROPERTY DETAIL
    // ════════════════════════════════════════════════════════════════════════

    private ChatResponse showPropertyDetail(Session s, String sessionId, String lower) {
        Long id = extractPropertyId(lower);
        if (id == null) {
            return text(sessionId,
                "Which property? Tell me the property ID (e.g. \"#3\" or \"property 3\") " +
                "or first search and I'll show you options.");
        }

        Optional<Property> opt = propertyService.findById(id);
        if (opt.isEmpty()) {
            return text(sessionId, "I couldn't find property #" + id + ". Want to browse all listings instead?");
        }

        Property p = opt.get();
        String reply = "📍 " + p.getTitle() + "\n" +
                (p.getLocality() != null ? p.getLocality() + ", " : "") + p.getCity() + "\n\n" +
                "💰 " + formatPrice(p.getPriceInr()) +
                (p.getListingType().equalsIgnoreCase("RENT") ? "/month" : "") + "\n" +
                "🛏️ " + p.getBedrooms() + " BHK · " + p.getAreaSqft() + " sqft · " +
                p.getBathrooms() + " baths\n\n" +
                p.getDescription();

        return new ChatResponse(reply, sessionId,
                List.of(Map.of("kind", "property_detail", "item", p)));
    }

    private Long extractPropertyId(String text) {
        Matcher m = PROP_ID.matcher(text);
        while (m.find()) {
            long id = Long.parseLong(m.group(1));
            if (id > 0 && id < 10000) return id; // sanity bound
        }
        return null;
    }

    // ════════════════════════════════════════════════════════════════════════
    // LEAD CAPTURE FLOW
    // ════════════════════════════════════════════════════════════════════════

    private ChatResponse startLeadFlow(Session s, String sessionId) {
        s.flow = Flow.LEAD_NAME;
        s.data.clear();
        return text(sessionId,
            "Sure, I'll have an EstateHub agent reach out. 😊\n\nFirst — what's your name?");
    }

    // ════════════════════════════════════════════════════════════════════════
    // VIEWING SCHEDULING FLOW
    // ════════════════════════════════════════════════════════════════════════

    private ChatResponse startViewingFlow(Session s, String sessionId) {
        s.flow = Flow.VIEW_PROPERTY;
        s.data.clear();
        return text(sessionId,
            "Great, let's book a viewing! 🗓️\n\nWhich property would you like to visit? " +
            "Reply with the property ID (e.g. \"#3\" or \"property 3\").");
    }

    // ════════════════════════════════════════════════════════════════════════
    // FLOW CONTINUATION (state machine)
    // ════════════════════════════════════════════════════════════════════════

    private ChatResponse continueFlow(Session s, String sessionId, String text) {
        // Allow user to bail out
        String lower = text.toLowerCase().trim();
        if (matches(lower, "^(cancel|stop|nevermind|never mind|exit|quit)$")) {
            s.flow = null; s.data.clear();
            return text(sessionId, "No problem, cancelled. Anything else I can help with?");
        }

        switch (s.flow) {
            case LEAD_NAME: {
                if (text.length() < 2) return text(sessionId, "Could you share your full name?");
                s.data.put("name", text);
                s.flow = Flow.LEAD_PHONE;
                return text(sessionId, "Thanks " + text.split(" ")[0] + "! What's your phone number?");
            }
            case LEAD_PHONE: {
                if (!PHONE_RE.matcher(text).find()) {
                    return text(sessionId, "That doesn't look like a valid phone. Please share a 10-digit Indian mobile number.");
                }
                s.data.put("phone", text);
                s.flow = Flow.LEAD_REQUIREMENT;
                return text(sessionId, "Got it. Briefly, what are you looking for? (e.g. \"3BHK in Bangalore\")");
            }
            case LEAD_REQUIREMENT: {
                LeadRequest req = new LeadRequest();
                req.setName((String) s.data.get("name"));
                req.setPhone((String) s.data.get("phone"));
                req.setRequirement(text);
                req.setSource("chatbot");
                leadService.create(req);
                s.flow = null; s.data.clear();
                return text(sessionId,
                    "✅ All set! An EstateHub agent will call you within 24 hours. Have a great day!");
            }
            case VIEW_PROPERTY: {
                Long id = extractPropertyId(lower);
                if (id == null) {
                    return text(sessionId, "Please share a valid property ID like \"#3\" or \"property 3\".");
                }
                if (propertyService.findById(id).isEmpty()) {
                    return text(sessionId, "I couldn't find property #" + id + ". Try another ID.");
                }
                s.data.put("propertyId", id);
                s.flow = Flow.VIEW_NAME;
                return text(sessionId, "Got it. What's your name?");
            }
            case VIEW_NAME: {
                if (text.length() < 2) return text(sessionId, "Could you share your full name?");
                s.data.put("name", text);
                s.flow = Flow.VIEW_PHONE;
                return text(sessionId, "Thanks " + text.split(" ")[0] + "! Phone number?");
            }
            case VIEW_PHONE: {
                if (!PHONE_RE.matcher(text).find()) {
                    return text(sessionId, "Please share a valid 10-digit Indian mobile number.");
                }
                s.data.put("phone", text);
                s.flow = Flow.VIEW_DATE;
                return text(sessionId,
                    "When would you like to visit? Please share the date and time in this format: " +
                    "YYYY-MM-DD HH:MM (e.g. \"2026-05-15 15:30\").");
            }
            case VIEW_DATE: {
                LocalDateTime when = parseDate(text);
                if (when == null) {
                    return text(sessionId,
                        "I couldn't read that date. Please use the format YYYY-MM-DD HH:MM " +
                        "(e.g. \"2026-05-15 15:30\").");
                }
                ViewingRequest req = new ViewingRequest();
                req.setPropertyId((Long) s.data.get("propertyId"));
                req.setCustomerName((String) s.data.get("name"));
                req.setCustomerPhone((String) s.data.get("phone"));
                req.setScheduledAt(when);
                viewingService.schedule(req);
                s.flow = null; s.data.clear();
                return text(sessionId,
                    "✅ Viewing booked for " + when.format(DateTimeFormatter.ofPattern("EEE, MMM d 'at' h:mm a")) +
                    ". An agent will confirm the address shortly!");
            }
            default:
                s.flow = null;
                return text(sessionId, "Let's start over — what can I help you with?");
        }
    }

    private LocalDateTime parseDate(String text) {
        // Try a few common formats
        List<DateTimeFormatter> fmts = List.of(
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm"),
            DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm"),
            DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm"),
            DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")
        );
        for (DateTimeFormatter f : fmts) {
            try { return LocalDateTime.parse(text.trim(), f); } catch (Exception ignored) {}
        }
        return null;
    }

    // ════════════════════════════════════════════════════════════════════════
    // HELPERS
    // ════════════════════════════════════════════════════════════════════════

    private ChatResponse text(String sessionId, String reply) {
        return new ChatResponse(reply, sessionId, List.of());
    }

    private boolean matches(String haystack, String regex) {
        return Pattern.compile(regex, Pattern.CASE_INSENSITIVE).matcher(haystack).find();
    }

    private String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    private String formatPrice(BigDecimal v) {
        if (v == null) return "-";
        long n = v.longValue();
        if (n >= 1_00_00_000) return "₹" + String.format("%.2f Cr", n / 1.0e7);
        if (n >= 1_00_000)    return "₹" + String.format("%.2f L", n / 1.0e5);
        return "₹" + String.format("%,d", n);
    }
}
