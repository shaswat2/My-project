package com.estatehub.service;

import com.estatehub.dto.BookingRequest;
import com.estatehub.model.Booking;
import com.estatehub.model.Property;
import com.estatehub.model.User;
import com.estatehub.repository.BookingRepository;
import com.estatehub.repository.PropertyRepository;
import com.estatehub.security.AuthFacade;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class BookingService {

    private final BookingRepository bookingRepository;
    private final PropertyRepository propertyRepository;
    private final AuthFacade auth;

    public Booking create(BookingRequest req) {
        User guest = auth.currentUser();
        if (guest.getRole() != User.Role.GUEST) {
            throw new SecurityException("Only guests can book properties");
        }
        Property property = propertyRepository.findById(req.getPropertyId())
                .orElseThrow(() -> new IllegalArgumentException("Property not found"));

        if (property.getOwnerId() != null && property.getOwnerId().equals(guest.getId())) {
            throw new IllegalArgumentException("You cannot book your own property");
        }

        BigDecimal totalPrice = property.getPriceInr();
        if ("RENT".equalsIgnoreCase(property.getListingType())
                && req.getCheckOutDate() != null && req.getCheckInDate() != null) {
            long months = Math.max(1, ChronoUnit.MONTHS.between(req.getCheckInDate(), req.getCheckOutDate()));
            totalPrice = property.getPriceInr().multiply(BigDecimal.valueOf(months));
        }

        Booking booking = Booking.builder()
                .propertyId(property.getId())
                .guestId(guest.getId())
                .ownerId(property.getOwnerId() != null ? property.getOwnerId() : 0L)
                .checkInDate(req.getCheckInDate())
                .checkOutDate(req.getCheckOutDate())
                .totalPrice(totalPrice)
                .message(req.getMessage())
                .status(Booking.Status.PENDING)
                .build();

        Booking saved = bookingRepository.save(booking);
        log.info("Booking created: id={} property={} guest={}", saved.getId(), property.getId(), guest.getId());
        return saved;
    }

    public List<Booking> myBookings() {
        User user = auth.currentUser();
        if (user.getRole() == User.Role.OWNER) {
            return bookingRepository.findByOwnerIdOrderByCreatedAtDesc(user.getId());
        }
        return bookingRepository.findByGuestIdOrderByCreatedAtDesc(user.getId());
    }

    public Booking updateStatus(Long bookingId, Booking.Status newStatus) {
        User user = auth.currentUser();
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new IllegalArgumentException("Booking not found"));

        // Owner can confirm/reject; Guest can cancel
        if (user.getRole() == User.Role.OWNER && booking.getOwnerId().equals(user.getId())) {
            if (newStatus == Booking.Status.CONFIRMED || newStatus == Booking.Status.REJECTED
                    || newStatus == Booking.Status.COMPLETED) {
                booking.setStatus(newStatus);
                return bookingRepository.save(booking);
            }
        } else if (user.getRole() == User.Role.GUEST && booking.getGuestId().equals(user.getId())) {
            if (newStatus == Booking.Status.CANCELLED) {
                booking.setStatus(newStatus);
                return bookingRepository.save(booking);
            }
        }
        throw new SecurityException("Not authorized to perform this status change");
    }
}
