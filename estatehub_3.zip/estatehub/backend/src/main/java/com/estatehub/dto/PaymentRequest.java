package com.estatehub.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PaymentRequest {
    /** Last 4 digits of (mock) card. Demo only — never store full card details. */
    @NotBlank
    @Pattern(regexp = "\\d{4}", message = "Last 4 digits required")
    private String cardLast4;
}
