package com.estatehub.service;

import com.estatehub.model.Property;
import com.estatehub.model.User;
import com.estatehub.repository.PropertyRepository;
import com.estatehub.security.AuthFacade;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class PropertyService {

    private final PropertyRepository repository;
    private final AuthFacade auth;

    public List<Property> findAll() { return repository.findAll(); }

    public List<Property> findFeatured() { return repository.findByFeaturedTrue(); }

    public Optional<Property> findById(Long id) { return repository.findById(id); }

    public List<Property> myProperties() {
        User u = auth.currentUser();
        return repository.findByOwnerIdOrderByCreatedAtDesc(u.getId());
    }

    public List<Property> search(String city, String type, String listingType,
                                 Integer minBedrooms, BigDecimal minPrice, BigDecimal maxPrice,
                                 int limit) {
        return repository.search(city, type, listingType, minBedrooms, minPrice, maxPrice)
                .stream().limit(limit).toList();
    }

    public Property create(Property p) {
        User owner = auth.currentUser();
        if (owner.getRole() != User.Role.OWNER) {
            throw new SecurityException("Only owners can list properties");
        }
        p.setId(null);
        p.setOwnerId(owner.getId());
        return repository.save(p);
    }

    public Property update(Long id, Property updated) {
        User u = auth.currentUser();
        Property existing = repository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Property not found"));
        if (u.getRole() != User.Role.ADMIN
                && (existing.getOwnerId() == null || !existing.getOwnerId().equals(u.getId()))) {
            throw new SecurityException("You can only edit your own properties");
        }
        // Preserve immutable fields
        updated.setId(id);
        updated.setOwnerId(existing.getOwnerId());
        updated.setCreatedAt(existing.getCreatedAt());
        return repository.save(updated);
    }

    public void delete(Long id) {
        User u = auth.currentUser();
        Property existing = repository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Property not found"));
        if (u.getRole() != User.Role.ADMIN
                && (existing.getOwnerId() == null || !existing.getOwnerId().equals(u.getId()))) {
            throw new SecurityException("You can only delete your own properties");
        }
        repository.deleteById(id);
    }
}
