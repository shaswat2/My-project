package com.estatehub.repository;

import com.estatehub.model.Property;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.util.List;

public interface PropertyRepository extends JpaRepository<Property, Long> {

    List<Property> findByFeaturedTrue();
    List<Property> findByOwnerIdOrderByCreatedAtDesc(Long ownerId);

    @Query("""
            SELECT p FROM Property p
            WHERE (:city IS NULL OR LOWER(p.city) LIKE LOWER(CONCAT('%', :city, '%')))
              AND (:type IS NULL OR LOWER(p.type) = LOWER(:type))
              AND (:listingType IS NULL OR LOWER(p.listingType) = LOWER(:listingType))
              AND (:minBedrooms IS NULL OR p.bedrooms >= :minBedrooms)
              AND (:maxPrice IS NULL OR p.priceInr <= :maxPrice)
              AND (:minPrice IS NULL OR p.priceInr >= :minPrice)
            ORDER BY p.featured DESC, p.priceInr ASC
            """)
    List<Property> search(
            @Param("city") String city,
            @Param("type") String type,
            @Param("listingType") String listingType,
            @Param("minBedrooms") Integer minBedrooms,
            @Param("minPrice") BigDecimal minPrice,
            @Param("maxPrice") BigDecimal maxPrice
    );
}
