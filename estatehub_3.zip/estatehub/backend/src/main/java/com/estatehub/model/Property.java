package com.estatehub.model;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "properties")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Property {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String title;

    @Column(length = 2000)
    private String description;

    @Column(nullable = false)
    private String city;

    private String locality;

    @Column(nullable = false)
    private String type;

    @Column(name = "listing_type", nullable = false)
    private String listingType;

    private Integer bedrooms;
    private Integer bathrooms;
    private Double areaSqft;

    @Column(name = "price_inr", nullable = false, precision = 19, scale = 2)
    private BigDecimal priceInr;

    private String imageUrl;

    @Column(length = 1000)
    private String amenities;

    private Boolean featured;

    @Column(name = "owner_id")
    private Long ownerId;

    private Instant createdAt;

    @PrePersist
    void onCreate() {
        if (createdAt == null) createdAt = Instant.now();
        if (featured == null) featured = false;
    }
}
