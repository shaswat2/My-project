package com.estatehub.controller;

import com.estatehub.dto.BookingRequest;
import com.estatehub.dto.PaymentRequest;
import com.estatehub.model.Booking;
import com.estatehub.service.BookingService;
import com.estatehub.service.PaymentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/bookings")
@RequiredArgsConstructor
public class BookingController {

    private final BookingService bookingService;
    private final PaymentService paymentService;

    @PostMapping
    public Booking create(@Valid @RequestBody BookingRequest req) {
        return bookingService.create(req);
    }

    @GetMapping("/me")
    public List<Booking> mine() {
        return bookingService.myBookings();
    }

    @PutMapping("/{id}/status")
    public Booking updateStatus(@PathVariable Long id, @RequestBody Map<String, String> body) {
        Booking.Status status = Booking.Status.valueOf(body.get("status").toUpperCase());
        return bookingService.updateStatus(id, status);
    }

    /** Mock payment endpoint. Guest must be the booking's guest, booking must be CONFIRMED. */
    @PostMapping("/{id}/pay")
    public Booking pay(@PathVariable Long id, @Valid @RequestBody PaymentRequest req) {
        return paymentService.charge(id, req.getCardLast4());
    }
}
