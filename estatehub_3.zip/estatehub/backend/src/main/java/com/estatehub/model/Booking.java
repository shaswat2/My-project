package com.estatehub.model;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;

@Entity
@Table(name = "bookings")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "property_id", nullable = false)
    private Long propertyId;

    @Column(name = "guest_id", nullable = false)
    private Long guestId;

    @Column(name = "owner_id", nullable = false)
    private Long ownerId;

    /** For RENT: lease start. For SALE: preferred visit date. */
    private LocalDate checkInDate;

    /** For RENT only: lease end. */
    private LocalDate checkOutDate;

    @Column(precision = 19, scale = 2)
    private BigDecimal totalPrice;

    @Column(length = 1000)
    private String message;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Status status;

    // ─── Payment fields (mock for demo; real Razorpay/Stripe drops in here) ───
    @Enumerated(EnumType.STRING)
    @Column(name = "payment_status")
    private PaymentStatus paymentStatus;

    @Column(name = "payment_id")
    private String paymentId;          // mock txn id like "MOCK_TXN_xxxxx"

    private Instant paidAt;

    private Instant createdAt;

    @PrePersist
    void onCreate() {
        this.createdAt = Instant.now();
        if (status == null) status = Status.PENDING;
        if (paymentStatus == null) paymentStatus = PaymentStatus.UNPAID;
    }

    public enum Status { PENDING, CONFIRMED, REJECTED, CANCELLED, COMPLETED }
    public enum PaymentStatus { UNPAID, PAID, REFUNDED }
}
