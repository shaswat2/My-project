# EstateHub — Real Estate Management Platform

A full-stack real estate platform with **two user roles** (Owner and Guest), JWT authentication,
property listings, booking flow, and a smart rule-based AI chat assistant.

## Stack

| Layer | Tech |
|---|---|
| Backend | Java 17, Spring Boot 3.3, Spring Security 6, Spring Data JPA |
| Auth | JWT (jjwt 0.12), BCrypt password hashing |
| Database | MySQL 8 (default) — H2 fallback available |
| Chatbot | Rule-based, runs against the same DB |
| Frontend | React 18, Vite, React Router 6, Axios, Lucide icons |

## What you can do

| Action | Who |
|---|---|
| Browse / search 100 seeded properties across 5 cities | Anyone (public) |
| View property details, amenities, gallery | Anyone |
| Submit an enquiry on a property | Anyone |
| Chat with Aria (the bot) | Anyone |
| **Sign up as Owner or Guest** | Anyone |
| List a new property | Owner only |
| Edit / delete own properties | Owner only |
| See incoming booking requests | Owner only |
| Confirm / reject bookings | Owner only |
| **Book a property** (rent dates or visit request) | Guest only |
| **Pay for a confirmed booking** (mock payment gateway) | Guest only |
| See your booking history | Guest only |
| Cancel a booking | Guest only |

## Demo accounts (auto-created on first run)

| Role | Email | Password |
|---|---|---|
| Owner | owner1@estatehub.com | password123 |
| Owner | owner2@estatehub.com | password123 |
| Owner | owner3@estatehub.com | password123 |
| Guest | guest@estatehub.com | password123 |

The 100 seed properties are distributed round-robin among the three owners.

## Prerequisites

- **Java 17 or 21** — `java -version`
- **Maven 3.8+** — `mvn -version`
- **Node 18+** + npm
- **MySQL 8** running locally (you can use MySQL Workbench's default `Local instance MySQL80`)

## Setup — IntelliJ (Backend) + VS Code (Frontend)

### 1. MySQL — set the password

Open `backend/src/main/resources/application.properties`. Default has:
```properties
spring.datasource.username=root
spring.datasource.password=root
```
Change `root` (the password value) to your actual MySQL password. The `estatehub` database
will be auto-created on first run.

### 2. IntelliJ — open backend

1. **File → Open** → select the `backend` folder → **Trust Project**
2. Wait for Maven to download dependencies (~3 min first time)
3. **Install Lombok plugin**: Settings → Plugins → "Lombok" → Install → Restart
4. Settings → Build → Compiler → Annotation Processors → enable annotation processing
5. Set Project SDK to Java 17 (or 21)
6. Click ▶ on `EstateHubApplication.java`
7. Wait for `Started EstateHubApplication` → backend is on **http://localhost:8080**

On startup it will:
- Create the `estatehub` database in MySQL
- Auto-generate tables (`users`, `properties`, `bookings`, `leads`, `viewings`)
- Seed 4 demo users + 100 properties

### 3. VS Code — open frontend

1. **File → Open Folder** → select the `frontend` folder
2. In VS Code's terminal (Ctrl+`):
   ```bash
   npm install
   npm run dev
   ```
3. Open **http://localhost:5173**

### 4. Try it

1. **Browse** — home + properties pages work without login
2. **Sign in as a guest** → owner1@estatehub.com / password123 (it'll redirect to dashboard)
   - Hmm wait — log in with **guest@estatehub.com / password123** instead → guest dashboard
3. From any property page → click **Book now** → fill date(s) → submit
4. **Sign out**, sign back in as **owner1@estatehub.com / password123**
5. Owner dashboard → see the new pending booking → click ✓ to confirm
6. Click **List a property** → fill the form → save → see it in your listings

## What's NOT built yet (so you know)

- ✅ Mock payment gateway (Razorpay / Stripe drop-in ready — see `PaymentService.java`)
- ❌ Email/SMS notifications
- ❌ Image uploads (you currently use external URLs like Unsplash)
- ❌ Reviews / ratings
- ❌ Map view
- ❌ Admin role UI

These are the natural next features if you want them.

## Project structure

```
estatehub/
├── backend/                              Spring Boot
│   └── src/main/
│       ├── java/com/estatehub/
│       │   ├── EstateHubApplication.java
│       │   ├── controller/               Auth, Property, Booking, Lead, Viewing, Chat
│       │   ├── service/                  Auth, JWT, Property, Booking, Lead, Viewing, Chat, DataSeeder
│       │   ├── security/                 SecurityConfig, JwtAuthFilter, AuthFacade, UserDetailsService
│       │   ├── model/                    User, Property, Booking, Lead, Viewing
│       │   ├── repository/               Spring Data interfaces
│       │   ├── dto/
│       │   └── exception/
│       └── resources/
│           ├── application.properties
│           └── seed-properties.json     100 properties × 5 cities
└── frontend/                             React + Vite
    └── src/
        ├── App.jsx
        ├── context/AuthContext.jsx
        ├── components/                   Navbar, Footer, ChatWidget, PropertyCard, BookingModal, ProtectedRoute
        ├── pages/                        Home, Properties, PropertyDetail, About, Contact,
        │                                 Login, Register, OwnerDashboard, GuestDashboard, PropertyForm
        ├── services/api.js               Axios + JWT interceptor
        └── styles/                       global.css + chat.css
```

## API Reference

### Public
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/properties` | List/search |
| GET | `/api/properties/featured` | Featured |
| GET | `/api/properties/{id}` | Single property |
| POST | `/api/auth/register` | Sign up |
| POST | `/api/auth/login` | Sign in → returns JWT |
| POST | `/api/leads` | Submit a lead |
| POST | `/api/chat` | Talk to Aria |

### Auth-required (Bearer token)
| Method | Endpoint | Role |
|---|---|---|
| GET | `/api/properties/me` | Owner: my listings |
| POST | `/api/properties` | Owner |
| PUT | `/api/properties/{id}` | Owner (own only) |
| DELETE | `/api/properties/{id}` | Owner (own only) |
| POST | `/api/bookings` | Guest |
| GET | `/api/bookings/me` | Owner or Guest |
| PUT | `/api/bookings/{id}/status` | Owner: confirm/reject; Guest: cancel |

## Switching to H2 (no MySQL needed)

Comment the MySQL block in `application.properties` and uncomment the H2 block.
H2 console at http://localhost:8080/h2-console.

## Deployment notes

- **Backend**: `mvn clean package` → JAR. Set DB credentials and `app.jwt.secret` as env vars.
- **Frontend**: `npm run build` → static files in `dist/`. Update axios baseURL or use a reverse proxy.
- **JWT secret**: replace the dev secret in production with a random 32+ char string.
- **CORS**: update `cors.allowed-origins` for your production frontend URL.

## License

MIT — extend as needed.
