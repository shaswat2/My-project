import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  timeout: 90000,
  headers: { 'Content-Type': 'application/json' },
})

// ─── Auth interceptor ──────────────────────────────────────────────────────
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('estatehub_token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

api.interceptors.response.use(
  (res) => res,
  (err) => {
    // Auto-logout on expired/invalid token
    if (err.response?.status === 401) {
      localStorage.removeItem('estatehub_token')
      localStorage.removeItem('estatehub_user')
    }
    return Promise.reject(err)
  }
)

// ─── Auth ──────────────────────────────────────────────────────────────────
export const register = (payload) => api.post('/auth/register', payload).then((r) => r.data)
export const login = (payload) => api.post('/auth/login', payload).then((r) => r.data)

// ─── Properties ────────────────────────────────────────────────────────────
export const fetchProperties = (params = {}) => api.get('/properties', { params }).then((r) => r.data)
export const fetchFeaturedProperties = () => api.get('/properties/featured').then((r) => r.data)
export const fetchProperty = (id) => api.get(`/properties/${id}`).then((r) => r.data)
export const fetchMyProperties = () => api.get('/properties/me').then((r) => r.data)
export const createProperty = (p) => api.post('/properties', p).then((r) => r.data)
export const updateProperty = (id, p) => api.put(`/properties/${id}`, p).then((r) => r.data)
export const deleteProperty = (id) => api.delete(`/properties/${id}`).then((r) => r.data)

// ─── Bookings ──────────────────────────────────────────────────────────────
export const createBooking = (payload) => api.post('/bookings', payload).then((r) => r.data)
export const fetchMyBookings = () => api.get('/bookings/me').then((r) => r.data)
export const updateBookingStatus = (id, status) =>
  api.put(`/bookings/${id}/status`, { status }).then((r) => r.data)
export const payForBooking = (id, cardLast4) =>
  api.post(`/bookings/${id}/pay`, { cardLast4 }).then((r) => r.data)

// ─── Leads (public) ────────────────────────────────────────────────────────
export const submitLead = (payload) => api.post('/leads', payload).then((r) => r.data)

// ─── Chat ──────────────────────────────────────────────────────────────────
export const sendChatMessage = (sessionId, message) =>
  api.post('/chat', { sessionId, message }).then((r) => r.data)

export default api
