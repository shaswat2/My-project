import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Plus, Edit2, Trash2, Check, X, Home, Calendar, IndianRupee } from 'lucide-react'
import {
  fetchMyProperties, deleteProperty,
  fetchMyBookings, updateBookingStatus
} from '../services/api'
import { formatPrice } from '../components/PropertyCard'
import { useAuth } from '../context/AuthContext'

export default function OwnerDashboard() {
  const { user } = useAuth()
  const [tab, setTab] = useState('properties')
  const [properties, setProperties] = useState([])
  const [bookings, setBookings] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => { loadAll() }, [])

  async function loadAll() {
    setLoading(true)
    try {
      const [props, books] = await Promise.all([fetchMyProperties(), fetchMyBookings()])
      setProperties(props)
      setBookings(books)
    } finally {
      setLoading(false)
    }
  }

  async function handleDelete(id) {
    if (!confirm('Delete this property? This cannot be undone.')) return
    await deleteProperty(id)
    setProperties((p) => p.filter((x) => x.id !== id))
  }

  async function handleBookingAction(id, status) {
    const updated = await updateBookingStatus(id, status)
    setBookings((b) => b.map((x) => (x.id === id ? updated : x)))
  }

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <div>
          <h1>Welcome back, {user?.name?.split(' ')[0]} 👋</h1>
          <p>Manage your properties and incoming bookings.</p>
        </div>
        <Link to="/owner/properties/new" className="btn btn-primary">
          <Plus size={16} /> List a property
        </Link>
      </div>

      <div className="dashboard-stats">
        <div className="stat-card">
          <Home size={24} color="var(--primary)" />
          <div><div className="stat-num">{properties.length}</div><div className="stat-label">Listings</div></div>
        </div>
        <div className="stat-card">
          <Calendar size={24} color="var(--accent)" />
          <div>
            <div className="stat-num">{bookings.filter((b) => b.status === 'PENDING').length}</div>
            <div className="stat-label">Pending bookings</div>
          </div>
        </div>
        <div className="stat-card">
          <IndianRupee size={24} color="var(--success)" />
          <div>
            <div className="stat-num">{bookings.filter((b) => b.status === 'CONFIRMED').length}</div>
            <div className="stat-label">Confirmed</div>
          </div>
        </div>
      </div>

      <div className="dashboard-tabs">
        <button className={tab === 'properties' ? 'tab active' : 'tab'} onClick={() => setTab('properties')}>
          My Properties ({properties.length})
        </button>
        <button className={tab === 'bookings' ? 'tab active' : 'tab'} onClick={() => setTab('bookings')}>
          Bookings ({bookings.length})
        </button>
      </div>

      {loading ? (
        <p>Loading...</p>
      ) : tab === 'properties' ? (
        <PropertyTable properties={properties} onDelete={handleDelete} />
      ) : (
        <BookingTable bookings={bookings} role="OWNER" onAction={handleBookingAction} />
      )}
    </div>
  )
}

function PropertyTable({ properties, onDelete }) {
  if (properties.length === 0) {
    return (
      <div className="empty-state">
        <h3>No properties yet</h3>
        <p>List your first property to start receiving bookings.</p>
        <Link to="/owner/properties/new" className="btn btn-primary"><Plus size={16} /> Add property</Link>
      </div>
    )
  }
  return (
    <div className="table-card">
      <table className="data-table">
        <thead>
          <tr><th>Property</th><th>Type</th><th>Price</th><th>City</th><th>Featured</th><th></th></tr>
        </thead>
        <tbody>
          {properties.map((p) => (
            <tr key={p.id}>
              <td>
                <Link to={`/properties/${p.id}`} className="cell-link">
                  <img src={p.imageUrl} alt="" className="row-thumb" />
                  <span>{p.title}</span>
                </Link>
              </td>
              <td><span className="pill">{p.listingType}</span> {p.type}</td>
              <td><strong>{formatPrice(p.priceInr, p.listingType)}</strong></td>
              <td>{p.locality ? `${p.locality}, ${p.city}` : p.city}</td>
              <td>{p.featured ? '⭐' : '—'}</td>
              <td className="row-actions">
                <Link to={`/owner/properties/${p.id}/edit`} className="icon-btn" title="Edit">
                  <Edit2 size={16} />
                </Link>
                <button className="icon-btn danger" onClick={() => onDelete(p.id)} title="Delete">
                  <Trash2 size={16} />
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export function BookingTable({ bookings, role, onAction }) {
  if (bookings.length === 0) {
    return (
      <div className="empty-state">
        <h3>No bookings yet</h3>
        <p>{role === 'OWNER' ? "Bookings on your properties will appear here." : "Book a property to see it here."}</p>
      </div>
    )
  }
  return (
    <div className="table-card">
      <table className="data-table">
        <thead>
          <tr>
            <th>Booking</th><th>Dates</th><th>Total</th><th>Status</th><th></th>
          </tr>
        </thead>
        <tbody>
          {bookings.map((b) => (
            <tr key={b.id}>
              <td>
                <Link to={`/properties/${b.propertyId}`} className="cell-link">Property #{b.propertyId}</Link>
                {b.message && <div className="row-message">"{b.message}"</div>}
              </td>
              <td>
                {b.checkInDate}{b.checkOutDate && ` → ${b.checkOutDate}`}
              </td>
              <td><strong>{formatPrice(b.totalPrice, '')}</strong></td>
              <td><span className={`status ${b.status.toLowerCase()}`}>{b.status}</span></td>
              <td className="row-actions">
                {role === 'OWNER' && b.status === 'PENDING' && (
                  <>
                    <button className="icon-btn success" title="Confirm"
                            onClick={() => onAction(b.id, 'CONFIRMED')}>
                      <Check size={16} />
                    </button>
                    <button className="icon-btn danger" title="Reject"
                            onClick={() => onAction(b.id, 'REJECTED')}>
                      <X size={16} />
                    </button>
                  </>
                )}
                {role === 'GUEST' && (b.status === 'PENDING' || b.status === 'CONFIRMED') && (
                  <button className="btn btn-ghost btn-sm" onClick={() => onAction(b.id, 'CANCELLED')}>
                    Cancel
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
