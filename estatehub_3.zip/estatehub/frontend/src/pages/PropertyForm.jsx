import { useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { Save, ArrowLeft } from 'lucide-react'
import { createProperty, updateProperty, fetchProperty } from '../services/api'

const EMPTY = {
  title: '', description: '', city: '', locality: '',
  type: 'APARTMENT', listingType: 'SALE',
  bedrooms: 2, bathrooms: 2, areaSqft: 1000, priceInr: '',
  imageUrl: '', amenities: '', featured: false,
}

export default function PropertyForm() {
  const { id } = useParams()
  const isEdit = Boolean(id)
  const navigate = useNavigate()
  const [form, setForm] = useState(EMPTY)
  const [error, setError] = useState('')
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (isEdit) {
      fetchProperty(id).then((p) => setForm({ ...EMPTY, ...p }))
    }
  }, [id, isEdit])

  function update(key, val) {
    setForm((f) => ({ ...f, [key]: val }))
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    setSaving(true)
    try {
      const payload = { ...form, priceInr: Number(form.priceInr), areaSqft: Number(form.areaSqft) }
      if (isEdit) await updateProperty(id, payload)
      else await createProperty(payload)
      navigate('/owner')
    } catch (err) {
      setError(err.response?.data?.message || 'Could not save property')
      setSaving(false)
    }
  }

  return (
    <div className="form-page">
      <button className="btn btn-ghost btn-sm" onClick={() => navigate('/owner')} style={{ marginBottom: 16 }}>
        <ArrowLeft size={14} /> Back to dashboard
      </button>
      <h1>{isEdit ? 'Edit property' : 'List a new property'}</h1>
      <p style={{ color: 'var(--text-muted)', marginBottom: 32 }}>
        Fill in the details below. Provide a clear title and an attractive image URL — listings with images get 5x more views.
      </p>

      {error && <div className="auth-error">{error}</div>}

      <form onSubmit={handleSubmit} className="property-form">
        <div className="form-row">
          <label className="form-field" style={{ gridColumn: 'span 2' }}>Title *
            <input required value={form.title} onChange={(e) => update('title', e.target.value)}
                   placeholder="e.g. Modern 2BHK near OMR" />
          </label>
        </div>

        <div className="form-row">
          <label className="form-field" style={{ gridColumn: 'span 2' }}>Description
            <textarea rows={4} value={form.description}
                      onChange={(e) => update('description', e.target.value)}
                      placeholder="Describe the property's best features..." />
          </label>
        </div>

        <div className="form-row">
          <label className="form-field">City *
            <input required value={form.city} onChange={(e) => update('city', e.target.value)}
                   placeholder="Bangalore" />
          </label>
          <label className="form-field">Locality
            <input value={form.locality} onChange={(e) => update('locality', e.target.value)}
                   placeholder="Whitefield" />
          </label>
        </div>

        <div className="form-row">
          <label className="form-field">Type *
            <select value={form.type} onChange={(e) => update('type', e.target.value)}>
              <option value="APARTMENT">Apartment</option>
              <option value="VILLA">Villa</option>
              <option value="INDEPENDENT_HOUSE">Independent House</option>
              <option value="PLOT">Plot</option>
              <option value="COMMERCIAL">Commercial</option>
            </select>
          </label>
          <label className="form-field">Listing *
            <select value={form.listingType} onChange={(e) => update('listingType', e.target.value)}>
              <option value="SALE">For Sale</option>
              <option value="RENT">For Rent</option>
            </select>
          </label>
        </div>

        <div className="form-row">
          <label className="form-field">Bedrooms
            <input type="number" min={0} value={form.bedrooms}
                   onChange={(e) => update('bedrooms', Number(e.target.value))} />
          </label>
          <label className="form-field">Bathrooms
            <input type="number" min={0} value={form.bathrooms}
                   onChange={(e) => update('bathrooms', Number(e.target.value))} />
          </label>
          <label className="form-field">Area (sqft)
            <input type="number" min={0} value={form.areaSqft}
                   onChange={(e) => update('areaSqft', Number(e.target.value))} />
          </label>
        </div>

        <div className="form-row">
          <label className="form-field">Price (INR) *
            <input type="number" required min={0} value={form.priceInr}
                   onChange={(e) => update('priceInr', e.target.value)}
                   placeholder={form.listingType === 'RENT' ? '25000 (per month)' : '8500000'} />
          </label>
          <label className="form-field" style={{ gridColumn: 'span 2' }}>Image URL
            <input type="url" value={form.imageUrl}
                   onChange={(e) => update('imageUrl', e.target.value)}
                   placeholder="https://images.unsplash.com/..." />
          </label>
        </div>

        <div className="form-row">
          <label className="form-field" style={{ gridColumn: 'span 2' }}>Amenities (comma separated)
            <input value={form.amenities}
                   onChange={(e) => update('amenities', e.target.value)}
                   placeholder="Pool, Gym, 24x7 Security, Parking" />
          </label>
          <label className="form-field" style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <input type="checkbox" checked={form.featured}
                   onChange={(e) => update('featured', e.target.checked)} />
            Mark as featured
          </label>
        </div>

        {form.imageUrl && (
          <div className="form-preview">
            <span>Preview:</span>
            <img src={form.imageUrl} alt="Preview" />
          </div>
        )}

        <div className="form-actions">
          <button type="button" className="btn btn-ghost" onClick={() => navigate('/owner')}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>
            <Save size={16} /> {saving ? 'Saving...' : (isEdit ? 'Save changes' : 'List property')}
          </button>
        </div>
      </form>
    </div>
  )
}
