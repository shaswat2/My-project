import { useState } from 'react'
import { useNavigate, useLocation, Link } from 'react-router-dom'
import { LogIn, AlertCircle } from 'lucide-react'
import { useAuth } from '../context/AuthContext'

export default function Login() {
  const [form, setForm] = useState({ email: '', password: '' })
  const [error, setError] = useState('')
  const { login, loading } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const from = location.state?.from?.pathname || '/'

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    try {
      const user = await login(form.email, form.password)
      // Redirect to role-appropriate dashboard
      if (user.role === 'OWNER') navigate('/owner')
      else if (user.role === 'GUEST') navigate('/dashboard')
      else navigate(from)
    } catch (err) {
      setError(err.response?.data?.message || 'Invalid email or password')
    }
  }

  return (
    <div className="auth-page">
      <div className="auth-card">
        <h1>Welcome back</h1>
        <p className="auth-subtitle">Sign in to manage your properties or bookings.</p>

        {error && (
          <div className="auth-error">
            <AlertCircle size={16} /> {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="auth-form">
          <label>Email
            <input type="email" required value={form.email}
                   onChange={(e) => setForm({ ...form, email: e.target.value })}
                   placeholder="you@example.com" />
          </label>
          <label>Password
            <input type="password" required value={form.password}
                   onChange={(e) => setForm({ ...form, password: e.target.value })}
                   placeholder="••••••••" />
          </label>
          <button type="submit" className="btn btn-primary" disabled={loading}>
            <LogIn size={16} /> {loading ? 'Signing in...' : 'Sign in'}
          </button>
        </form>

        <p className="auth-footer">
          New to EstateHub? <Link to="/register">Create an account</Link>
        </p>

        <div className="auth-demo">
          <strong>Demo accounts:</strong>
          <code>owner1@estatehub.com / password123</code> (Owner)<br/>
          <code>guest@estatehub.com / password123</code> (Guest)
        </div>
      </div>
    </div>
  )
}
