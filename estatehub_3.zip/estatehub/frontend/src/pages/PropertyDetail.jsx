import { useEffect, useState } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import { MapPin, Bed, Bath, Maximize2, Calendar, Tag, LogIn } from 'lucide-react'
import { fetchProperty, submitLead } from '../services/api'
import { formatPrice } from '../components/PropertyCard'
import { useAuth } from '../context/AuthContext'
import BookingModal from '../components/BookingModal'

const FALLBACK_IMG = 'https://images.unsplash.com/photo-1568605114967-8130f3a36994?w=1600&q=80'

export default function PropertyDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { user } = useAuth()
  const [property, setProperty] = useState(null)
  const [loading, setLoading] = useState(true)
  const [showBooking, setShowBooking] = useState(false)
  const [form, setForm] = useState({ name: '', email: '', phone: '', requirement: '' })
  const [submitted, setSubmitted] = useState(false)

  useEffect(() => {
    setLoading(true)
    fetchProperty(id).then(setProperty).catch(() => setProperty(null)).finally(() => setLoading(false))
  }, [id])

  async function handleEnquiry(e) {
    e.preventDefault()
    try {
      await submitLead({ ...form, propertyId: Number(id), source: 'property-detail' })
      setSubmitted(true)
      setForm({ name: '', email: '', phone: '', requirement: '' })
    } catch {
      alert('Could not send your enquiry.')
    }
  }

  function handleBookClick() {
    if (!user) {
      navigate('/login', { state: { from: { pathname: `/properties/${id}` } } })
      return
    }
    if (user.role !== 'GUEST') {
      alert('Only guest accounts can book. Please sign in with a guest account.')
      return
    }
    setShowBooking(true)
  }

  if (loading) return <p style={{ padding: 60, textAlign: 'center' }}>Loading...</p>
  if (!property) return <div className="empty-state"><h3>Property not found</h3></div>

  const amenities = (property.amenities || '').split(',').map((s) => s.trim()).filter(Boolean)
  const isOwnProperty = user?.role === 'OWNER' && property.ownerId === user.id

  return (
    <>
      <div className="detail-hero" style={{ backgroundImage: `url(${property.imageUrl || FALLBACK_IMG})` }} />
      <div className="detail-content">
        <div className="detail-card">
          <div className="detail-main">
            <span className={`property-badge ${property.listingType?.toLowerCase()}`}
                  style={{ position: 'static', display: 'inline-block', marginBottom: 16 }}>
              For {property.listingType === 'RENT' ? 'Rent' : 'Sale'}
            </span>
            <h1>{property.title}</h1>
            <div className="detail-location">
              <MapPin size={16} />
              {property.locality ? `${property.locality}, ${property.city}` : property.city}
            </div>
            <div className="detail-price-large">
              {formatPrice(property.priceInr, property.listingType)}
              {property.listingType === 'RENT' && <span style={{ fontSize: 16, color: 'var(--text-muted)' }}> /month</span>}
            </div>

            <div className="detail-specs-grid">
              {property.bedrooms > 0 && (
                <div className="detail-spec">
                  <span className="detail-spec-label"><Bed size={14} style={{ display: 'inline', marginRight: 4 }} />Bedrooms</span>
                  <span className="detail-spec-value">{property.bedrooms}</span>
                </div>
              )}
              {property.bathrooms > 0 && (
                <div className="detail-spec">
                  <span className="detail-spec-label"><Bath size={14} style={{ display: 'inline', marginRight: 4 }} />Bathrooms</span>
                  <span className="detail-spec-value">{property.bathrooms}</span>
                </div>
              )}
              {property.areaSqft && (
                <div className="detail-spec">
                  <span className="detail-spec-label"><Maximize2 size={14} style={{ display: 'inline', marginRight: 4 }} />Area</span>
                  <span className="detail-spec-value">{property.areaSqft} sqft</span>
                </div>
              )}
              <div className="detail-spec">
                <span className="detail-spec-label"><Tag size={14} style={{ display: 'inline', marginRight: 4 }} />Type</span>
                <span className="detail-spec-value" style={{ fontSize: 14 }}>{property.type}</span>
              </div>
            </div>

            <h3 style={{ marginBottom: 12 }}>About this property</h3>
            <p className="detail-description">{property.description}</p>

            {amenities.length > 0 && (
              <>
                <h3 style={{ marginBottom: 12 }}>Amenities</h3>
                <div className="amenities-grid">
                  {amenities.map((a, i) => <span key={i} className="amenity-pill">{a}</span>)}
                </div>
              </>
            )}
          </div>

          <aside className="detail-side">
            {isOwnProperty ? (
              <>
                <h3>Your listing</h3>
                <p style={{ color: 'var(--text-muted)', marginBottom: 16 }}>
                  This is one of your properties. Manage it from your dashboard.
                </p>
                <Link to={`/owner/properties/${id}/edit`} className="btn btn-primary" style={{ width: '100%', marginBottom: 8 }}>
                  Edit property
                </Link>
                <Link to="/owner" className="btn btn-ghost" style={{ width: '100%' }}>
                  View dashboard
                </Link>
              </>
            ) : (
              <>
                <h3>{property.listingType === 'RENT' ? 'Book this rental' : 'Schedule a visit'}</h3>
                <p style={{ color: 'var(--text-muted)', marginBottom: 16, fontSize: 13 }}>
                  {user
                    ? "Click below to send a booking request to the owner."
                    : "Sign in to book or contact the owner directly below."}
                </p>
                <button className="btn btn-primary" onClick={handleBookClick} style={{ width: '100%', marginBottom: 16 }}>
                  {user ? <><Calendar size={16} /> {property.listingType === 'RENT' ? 'Book now' : 'Request visit'}</>
                        : <><LogIn size={16} /> Sign in to book</>}
                </button>

                <div className="enquiry-divider">— or send an enquiry —</div>

                {submitted ? (
                  <div className="toast">✓ Enquiry sent! An agent will contact you.</div>
                ) : (
                  <form onSubmit={handleEnquiry}>
                    <input required placeholder="Your name" value={form.name}
                           onChange={(e) => setForm({ ...form, name: e.target.value })} />
                    <input required type="tel" placeholder="Phone" value={form.phone}
                           onChange={(e) => setForm({ ...form, phone: e.target.value })} />
                    <input type="email" placeholder="Email (optional)" value={form.email}
                           onChange={(e) => setForm({ ...form, email: e.target.value })} />
                    <textarea rows={3} placeholder="Message" value={form.requirement}
                              onChange={(e) => setForm({ ...form, requirement: e.target.value })} />
                    <button type="submit" className="btn btn-ghost" style={{ width: '100%' }}>
                      Send enquiry
                    </button>
                  </form>
                )}
              </>
            )}
          </aside>
        </div>
      </div>

      {showBooking && (
        <BookingModal property={property} onClose={() => setShowBooking(false)} />
      )}
    </>
  )
}
