import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { UserPlus, AlertCircle, Home, User } from 'lucide-react'
import { useAuth } from '../context/AuthContext'

export default function Register() {
  const [form, setForm] = useState({
    name: '', email: '', password: '', phone: '', role: 'GUEST'
  })
  const [error, setError] = useState('')
  const { register, loading } = useAuth()
  const navigate = useNavigate()

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    try {
      const user = await register(form)
      navigate(user.role === 'OWNER' ? '/owner' : '/dashboard')
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed')
    }
  }

  return (
    <div className="auth-page">
      <div className="auth-card">
        <h1>Create your account</h1>
        <p className="auth-subtitle">Choose how you'll use EstateHub.</p>

        <div className="role-selector">
          <button type="button"
            className={`role-card ${form.role === 'GUEST' ? 'selected' : ''}`}
            onClick={() => setForm({ ...form, role: 'GUEST' })}>
            <User size={28} />
            <span className="role-title">Guest</span>
            <span className="role-desc">Browse and book properties</span>
          </button>
          <button type="button"
            className={`role-card ${form.role === 'OWNER' ? 'selected' : ''}`}
            onClick={() => setForm({ ...form, role: 'OWNER' })}>
            <Home size={28} />
            <span className="role-title">Owner</span>
            <span className="role-desc">List and manage properties</span>
          </button>
        </div>

        {error && (
          <div className="auth-error">
            <AlertCircle size={16} /> {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="auth-form">
          <label>Full name
            <input type="text" required value={form.name}
                   onChange={(e) => setForm({ ...form, name: e.target.value })}
                   placeholder="Your name" />
          </label>
          <label>Email
            <input type="email" required value={form.email}
                   onChange={(e) => setForm({ ...form, email: e.target.value })}
                   placeholder="you@example.com" />
          </label>
          <label>Phone
            <input type="tel" value={form.phone}
                   onChange={(e) => setForm({ ...form, phone: e.target.value })}
                   placeholder="+91 98765 43210" />
          </label>
          <label>Password
            <input type="password" required minLength={6} value={form.password}
                   onChange={(e) => setForm({ ...form, password: e.target.value })}
                   placeholder="At least 6 characters" />
          </label>
          <button type="submit" className="btn btn-primary" disabled={loading}>
            <UserPlus size={16} /> {loading ? 'Creating account...' : 'Create account'}
          </button>
        </form>

        <p className="auth-footer">
          Already have an account? <Link to="/login">Sign in</Link>
        </p>
      </div>
    </div>
  )
}
