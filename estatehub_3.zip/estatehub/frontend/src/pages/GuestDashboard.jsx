import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Search, Calendar, CreditCard, X, CheckCircle } from 'lucide-react'
import { fetchMyBookings, updateBookingStatus, fetchProperty } from '../services/api'
import { useAuth } from '../context/AuthContext'
import { formatPrice } from '../components/PropertyCard'
import PaymentModal from '../components/PaymentModal'

export default function GuestDashboard() {
  const { user } = useAuth()
  const [bookings, setBookings] = useState([])
  const [propertyMap, setPropertyMap] = useState({})  // id → property
  const [loading, setLoading] = useState(true)
  const [payingBooking, setPayingBooking] = useState(null)

  useEffect(() => {
    refreshBookings()
  }, [])

  async function refreshBookings() {
    setLoading(true)
    try {
      const list = await fetchMyBookings()
      setBookings(list)
      // Fetch property details for each unique property in bookings
      const ids = [...new Set(list.map((b) => b.propertyId))]
      const props = await Promise.all(ids.map((id) => fetchProperty(id).catch(() => null)))
      const map = {}
      props.forEach((p) => { if (p) map[p.id] = p })
      setPropertyMap(map)
    } catch {
      setBookings([])
    } finally {
      setLoading(false)
    }
  }

  async function handleCancel(id) {
    if (!confirm('Cancel this booking?')) return
    const updated = await updateBookingStatus(id, 'CANCELLED')
    setBookings((b) => b.map((x) => (x.id === id ? updated : x)))
  }

  function handlePaymentDone(updatedBooking) {
    setBookings((b) => b.map((x) => (x.id === updatedBooking.id ? updatedBooking : x)))
    setPayingBooking(null)
  }

  const stats = {
    total: bookings.length,
    pending: bookings.filter((b) => b.status === 'PENDING').length,
    confirmed: bookings.filter((b) => b.status === 'CONFIRMED').length,
    paid: bookings.filter((b) => b.paymentStatus === 'PAID').length,
  }

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <div>
          <h1>Hi, {user?.name?.split(' ')[0]} 👋</h1>
          <p>Track your property bookings and find new places to stay or buy.</p>
        </div>
        <Link to="/properties" className="btn btn-primary">
          <Search size={16} /> Browse properties
        </Link>
      </div>

      <div className="dashboard-stats">
        <div className="stat-card">
          <Calendar size={24} color="var(--primary)" />
          <div>
            <div className="stat-num">{stats.total}</div>
            <div className="stat-label">Total bookings</div>
          </div>
        </div>
        <div className="stat-card">
          <Calendar size={24} color="var(--accent)" />
          <div>
            <div className="stat-num">{stats.pending}</div>
            <div className="stat-label">Pending</div>
          </div>
        </div>
        <div className="stat-card">
          <CheckCircle size={24} color="var(--success)" />
          <div>
            <div className="stat-num">{stats.confirmed}</div>
            <div className="stat-label">Confirmed</div>
          </div>
        </div>
        <div className="stat-card">
          <CreditCard size={24} color="var(--primary-dark)" />
          <div>
            <div className="stat-num">{stats.paid}</div>
            <div className="stat-label">Paid</div>
          </div>
        </div>
      </div>

      <h2 style={{ marginBottom: 16 }}>My Bookings</h2>

      {loading ? <p style={{ color: 'var(--text-muted)' }}>Loading...</p> : bookings.length === 0 ? (
        <div className="empty-state">
          <h3>No bookings yet</h3>
          <p>Browse our listings and book your first property.</p>
          <Link to="/properties" className="btn btn-primary"><Search size={16} /> Browse properties</Link>
        </div>
      ) : (
        <div className="table-card">
          <table className="data-table">
            <thead>
              <tr><th>Property</th><th>Dates</th><th>Total</th><th>Status</th><th>Payment</th><th></th></tr>
            </thead>
            <tbody>
              {bookings.map((b) => {
                const prop = propertyMap[b.propertyId]
                return (
                  <tr key={b.id}>
                    <td>
                      <Link to={`/properties/${b.propertyId}`} className="cell-link">
                        {prop?.imageUrl && <img src={prop.imageUrl} alt="" className="row-thumb" />}
                        <span>{prop?.title || `Property #${b.propertyId}`}</span>
                      </Link>
                      {b.message && <div className="row-message">"{b.message}"</div>}
                    </td>
                    <td>{b.checkInDate}{b.checkOutDate && ` → ${b.checkOutDate}`}</td>
                    <td><strong>{formatPrice(b.totalPrice, prop?.listingType || '')}</strong></td>
                    <td><span className={`status ${b.status.toLowerCase()}`}>{b.status}</span></td>
                    <td>
                      {b.paymentStatus === 'PAID' ? (
                        <span className="status confirmed">PAID</span>
                      ) : (
                        <span className="status pending">{b.paymentStatus || 'UNPAID'}</span>
                      )}
                    </td>
                    <td className="row-actions">
                      {b.status === 'CONFIRMED' && b.paymentStatus !== 'PAID' && (
                        <button className="btn btn-primary btn-sm"
                                onClick={() => setPayingBooking({ booking: b, property: prop })}>
                          <CreditCard size={14} /> Pay now
                        </button>
                      )}
                      {(b.status === 'PENDING' || b.status === 'CONFIRMED') && b.paymentStatus !== 'PAID' && (
                        <button className="btn btn-ghost btn-sm" onClick={() => handleCancel(b.id)}>
                          Cancel
                        </button>
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}

      {payingBooking && (
        <PaymentModal
          booking={payingBooking.booking}
          propertyTitle={payingBooking.property?.title || `Property #${payingBooking.booking.propertyId}`}
          propertyListingType={payingBooking.property?.listingType}
          onClose={() => setPayingBooking(null)}
          onPaid={handlePaymentDone}
        />
      )}
    </div>
  )
}
