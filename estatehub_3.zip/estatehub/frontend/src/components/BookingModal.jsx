import { useState } from 'react'
import { Calendar, X, CheckCircle } from 'lucide-react'
import { createBooking } from '../services/api'
import { formatPrice } from './PropertyCard'

export default function BookingModal({ property, onClose }) {
  const isRent = property.listingType === 'RENT'
  const today = new Date().toISOString().slice(0, 10)
  const [form, setForm] = useState({
    checkInDate: today,
    checkOutDate: isRent ? '' : null,
    message: '',
  })
  const [submitting, setSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [error, setError] = useState('')

  async function handleSubmit(e) {
    e.preventDefault()
    setSubmitting(true)
    setError('')
    try {
      await createBooking({
        propertyId: property.id,
        checkInDate: form.checkInDate,
        checkOutDate: isRent ? form.checkOutDate : null,
        message: form.message,
      })
      setSubmitted(true)
    } catch (err) {
      setError(err.response?.data?.message || 'Booking failed. Please try again.')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose}><X size={18} /></button>

        {submitted ? (
          <div className="modal-success">
            <CheckCircle size={48} color="var(--success)" />
            <h2>Booking request sent!</h2>
            <p>The owner will review and confirm shortly. You'll see updates on your dashboard.</p>
            <button className="btn btn-primary" onClick={onClose}>Done</button>
          </div>
        ) : (
          <>
            <h2>{isRent ? 'Book this rental' : 'Schedule a visit'}</h2>
            <p style={{ color: 'var(--text-muted)', marginBottom: 24 }}>
              {property.title} — <strong>{formatPrice(property.priceInr, property.listingType)}</strong>
            </p>

            {error && <div className="auth-error">{error}</div>}

            <form onSubmit={handleSubmit} className="auth-form">
              <label>{isRent ? 'Check-in date' : 'Preferred visit date'}
                <input type="date" required min={today}
                       value={form.checkInDate}
                       onChange={(e) => setForm({ ...form, checkInDate: e.target.value })} />
              </label>
              {isRent && (
                <label>Check-out date
                  <input type="date" required min={form.checkInDate}
                         value={form.checkOutDate || ''}
                         onChange={(e) => setForm({ ...form, checkOutDate: e.target.value })} />
                </label>
              )}
              <label>Message (optional)
                <textarea rows={3} value={form.message}
                          onChange={(e) => setForm({ ...form, message: e.target.value })}
                          placeholder={isRent ? "Any special requirements?" : "What would you like to know?"} />
              </label>
              <button type="submit" className="btn btn-primary" disabled={submitting}>
                <Calendar size={16} /> {submitting ? 'Sending...' : (isRent ? 'Request booking' : 'Request visit')}
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  )
}
