import { useState, useRef, useEffect } from 'react'
import { NavLink, Link, useNavigate } from 'react-router-dom'
import { Home as HomeIcon, ChevronDown, LogOut, LayoutDashboard, Plus } from 'lucide-react'
import { useAuth } from '../context/AuthContext'

export default function Navbar() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const [menuOpen, setMenuOpen] = useState(false)
  const menuRef = useRef(null)

  useEffect(() => {
    function clickOutside(e) {
      if (menuRef.current && !menuRef.current.contains(e.target)) setMenuOpen(false)
    }
    document.addEventListener('mousedown', clickOutside)
    return () => document.removeEventListener('mousedown', clickOutside)
  }, [])

  function handleLogout() {
    logout()
    setMenuOpen(false)
    navigate('/')
  }

  const dashboardPath = user?.role === 'OWNER' ? '/owner' : '/dashboard'

  return (
    <nav className="navbar">
      <div className="navbar-inner">
        <Link to="/" className="brand">
          <span className="brand-icon"><HomeIcon size={20} /></span>
          EstateHub
        </Link>
        <div className="nav-links">
          <NavLink to="/" end className="nav-link">Home</NavLink>
          <NavLink to="/properties" className="nav-link">Properties</NavLink>
          <NavLink to="/about" className="nav-link">About</NavLink>
          <NavLink to="/contact" className="nav-link">Contact</NavLink>

          {user ? (
            <div className="user-menu" ref={menuRef}>
              <button className="user-menu-trigger" onClick={() => setMenuOpen((o) => !o)}>
                <div className="user-avatar">{user.name?.[0]?.toUpperCase()}</div>
                <span className="user-name">{user.name?.split(' ')[0]}</span>
                <ChevronDown size={14} />
              </button>
              {menuOpen && (
                <div className="user-menu-dropdown">
                  <div className="user-menu-header">
                    <strong>{user.name}</strong>
                    <span>{user.email}</span>
                    <span className="user-role-tag">{user.role}</span>
                  </div>
                  <Link to={dashboardPath} className="menu-item" onClick={() => setMenuOpen(false)}>
                    <LayoutDashboard size={16} /> Dashboard
                  </Link>
                  {user.role === 'OWNER' && (
                    <Link to="/owner/properties/new" className="menu-item" onClick={() => setMenuOpen(false)}>
                      <Plus size={16} /> List property
                    </Link>
                  )}
                  <button className="menu-item danger" onClick={handleLogout}>
                    <LogOut size={16} /> Sign out
                  </button>
                </div>
              )}
            </div>
          ) : (
            <>
              <NavLink to="/login" className="nav-link">Sign in</NavLink>
              <Link to="/register" className="btn btn-primary btn-sm nav-cta">Sign up</Link>
            </>
          )}
        </div>
      </div>
    </nav>
  )
}
