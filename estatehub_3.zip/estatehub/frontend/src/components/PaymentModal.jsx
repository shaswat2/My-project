import { useState } from 'react'
import { CreditCard, X, CheckCircle, Lock, ShieldCheck } from 'lucide-react'
import { payForBooking } from '../services/api'
import { formatPrice } from './PropertyCard'

export default function PaymentModal({ booking, propertyTitle, propertyListingType, onClose, onPaid }) {
  const [card, setCard] = useState({ number: '', name: '', expiry: '', cvv: '' })
  const [submitting, setSubmitting] = useState(false)
  const [done, setDone] = useState(false)
  const [error, setError] = useState('')

  function formatCardNumber(v) {
    return v.replace(/\D/g, '').slice(0, 16).replace(/(\d{4})(?=\d)/g, '$1 ')
  }
  function formatExpiry(v) {
    const digits = v.replace(/\D/g, '').slice(0, 4)
    return digits.length > 2 ? `${digits.slice(0, 2)}/${digits.slice(2)}` : digits
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    const last4 = card.number.replace(/\D/g, '').slice(-4)
    if (last4.length !== 4) { setError('Please enter a valid 16-digit card number.'); return }
    if (!card.name.trim()) { setError('Cardholder name required.'); return }
    if (!/^\d{2}\/\d{2}$/.test(card.expiry)) { setError('Expiry must be MM/YY format.'); return }
    if (!/^\d{3,4}$/.test(card.cvv)) { setError('Invalid CVV.'); return }

    setSubmitting(true)
    try {
      // Simulate processing time for realism
      await new Promise((r) => setTimeout(r, 1200))
      const paid = await payForBooking(booking.id, last4)
      setDone(true)
      setTimeout(() => onPaid?.(paid), 1500)
    } catch (err) {
      setError(err.response?.data?.message || 'Payment failed. Please try again.')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box payment-modal" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose}><X size={18} /></button>

        {done ? (
          <div className="modal-success">
            <CheckCircle size={56} color="var(--success)" />
            <h2>Payment successful!</h2>
            <p>Your booking is confirmed. We've sent a receipt to your email.</p>
          </div>
        ) : (
          <>
            <div className="payment-header">
              <div className="payment-icon"><CreditCard size={20} /></div>
              <div>
                <h2 style={{ marginBottom: 2 }}>Complete payment</h2>
                <p style={{ color: 'var(--text-muted)', fontSize: 13 }}>
                  {propertyTitle} · {propertyListingType === 'RENT' ? 'Rental booking' : 'Property purchase'}
                </p>
              </div>
            </div>

            <div className="payment-amount">
              <span>Amount due</span>
              <strong>{formatPrice(booking.totalPrice, propertyListingType)}</strong>
            </div>

            <div className="demo-banner">
              <ShieldCheck size={14} />
              <span><strong>Demo mode</strong> — use any test card. No real payment is processed.</span>
            </div>

            {error && <div className="auth-error">{error}</div>}

            <form onSubmit={handleSubmit} className="payment-form">
              <label>Card number
                <input
                  type="text" inputMode="numeric" placeholder="4111 1111 1111 1111"
                  value={card.number}
                  onChange={(e) => setCard({ ...card, number: formatCardNumber(e.target.value) })}
                  maxLength={19} required
                />
              </label>
              <label>Cardholder name
                <input
                  type="text" placeholder="As on card"
                  value={card.name}
                  onChange={(e) => setCard({ ...card, name: e.target.value })}
                  required
                />
              </label>
              <div className="payment-row">
                <label>Expiry
                  <input
                    type="text" inputMode="numeric" placeholder="MM/YY"
                    value={card.expiry}
                    onChange={(e) => setCard({ ...card, expiry: formatExpiry(e.target.value) })}
                    maxLength={5} required
                  />
                </label>
                <label>CVV
                  <input
                    type="password" inputMode="numeric" placeholder="•••"
                    value={card.cvv}
                    onChange={(e) => setCard({ ...card, cvv: e.target.value.replace(/\D/g, '').slice(0, 4) })}
                    maxLength={4} required
                  />
                </label>
              </div>
              <button type="submit" className="btn btn-primary btn-pay" disabled={submitting}>
                <Lock size={14} /> {submitting ? 'Processing payment…' : `Pay ${formatPrice(booking.totalPrice, propertyListingType)}`}
              </button>
              <p className="payment-secure">
                <Lock size={11} /> Your card details are encrypted in transit (mocked for demo)
              </p>
            </form>
          </>
        )}
      </div>
    </div>
  )
}
