import { createContext, useContext, useState, useEffect } from 'react'
import { login as apiLogin, register as apiRegister } from '../services/api'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const stored = localStorage.getItem('estatehub_user')
    return stored ? JSON.parse(stored) : null
  })
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (user) {
      localStorage.setItem('estatehub_user', JSON.stringify(user))
    } else {
      localStorage.removeItem('estatehub_user')
    }
  }, [user])

  async function login(email, password) {
    setLoading(true)
    try {
      const data = await apiLogin({ email, password })
      localStorage.setItem('estatehub_token', data.token)
      const userObj = { id: data.userId, name: data.name, email: data.email, role: data.role }
      setUser(userObj)
      return userObj
    } finally {
      setLoading(false)
    }
  }

  async function register(payload) {
    setLoading(true)
    try {
      const data = await apiRegister(payload)
      localStorage.setItem('estatehub_token', data.token)
      const userObj = { id: data.userId, name: data.name, email: data.email, role: data.role }
      setUser(userObj)
      return userObj
    } finally {
      setLoading(false)
    }
  }

  function logout() {
    localStorage.removeItem('estatehub_token')
    localStorage.removeItem('estatehub_user')
    setUser(null)
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => useContext(AuthContext)
