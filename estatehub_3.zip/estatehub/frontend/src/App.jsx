import { Routes, Route } from 'react-router-dom'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import ChatWidget from './components/ChatWidget'
import ProtectedRoute from './components/ProtectedRoute'
import { AuthProvider } from './context/AuthContext'

import Home from './pages/Home'
import Properties from './pages/Properties'
import PropertyDetail from './pages/PropertyDetail'
import Contact from './pages/Contact'
import About from './pages/About'
import Login from './pages/Login'
import Register from './pages/Register'
import OwnerDashboard from './pages/OwnerDashboard'
import GuestDashboard from './pages/GuestDashboard'
import PropertyForm from './pages/PropertyForm'

export default function App() {
  return (
    <AuthProvider>
      <div className="app-shell">
        <Navbar />
        <main className="app-main">
          <Routes>
            {/* Public */}
            <Route path="/" element={<Home />} />
            <Route path="/properties" element={<Properties />} />
            <Route path="/properties/:id" element={<PropertyDetail />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />

            {/* Owner-only */}
            <Route path="/owner" element={
              <ProtectedRoute role="OWNER"><OwnerDashboard /></ProtectedRoute>
            } />
            <Route path="/owner/properties/new" element={
              <ProtectedRoute role="OWNER"><PropertyForm /></ProtectedRoute>
            } />
            <Route path="/owner/properties/:id/edit" element={
              <ProtectedRoute role="OWNER"><PropertyForm /></ProtectedRoute>
            } />

            {/* Guest-only */}
            <Route path="/dashboard" element={
              <ProtectedRoute role="GUEST"><GuestDashboard /></ProtectedRoute>
            } />
          </Routes>
        </main>
        <Footer />
        <ChatWidget />
      </div>
    </AuthProvider>
  )
}
