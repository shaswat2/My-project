package com.estatehub.service;

import com.estatehub.model.Property;
import com.estatehub.repository.PropertyRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class PropertyService {

    private final PropertyRepository repository;

    public List<Property> findAll() {
        return repository.findAll();
    }

    public List<Property> findFeatured() {
        return repository.findByFeaturedTrue();
    }

    public Optional<Property> findById(Long id) {
        return repository.findById(id);
    }

    public List<Property> search(String city, String type, String listingType,
                                 Integer minBedrooms, BigDecimal minPrice, BigDecimal maxPrice,
                                 int limit) {
        return repository.search(city, type, listingType, minBedrooms, minPrice, maxPrice)
                .stream()
                .limit(limit)
                .toList();
    }

    public Property create(Property property) {
        return repository.save(property);
    }

    public Property update(Long id, Property property) {
        property.setId(id);
        return repository.save(property);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}
