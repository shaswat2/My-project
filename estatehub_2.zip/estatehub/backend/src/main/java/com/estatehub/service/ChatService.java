package com.estatehub.service;

import com.estatehub.dto.ChatDtos.ChatResponse;
import com.estatehub.dto.LeadRequest;
import com.estatehub.dto.ViewingRequest;
import com.estatehub.model.Property;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Orchestrates the chatbot conversation:
 * 1. Maintain per-session message history
 * 2. Send to Claude with tool definitions
 * 3. If Claude calls a tool, execute it locally and feed the result back
 * 4. Loop until Claude returns a plain text response
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class ChatService {

    private final ClaudeApiClient claude;
    private final PropertyService propertyService;
    private final LeadService leadService;
    private final ViewingService viewingService;

    @Value("${anthropic.api.key}")
    private String apiKey;

    private static final int MAX_TOOL_LOOPS = 6;

    /** In-memory session store. Swap for Redis or DB if you want persistence. */
    private final Map<String, List<Map<String, Object>>> sessions = new ConcurrentHashMap<>();

    private static final String SYSTEM_PROMPT = """
            You are Aria, the friendly AI assistant for EstateHub — a real estate platform.
            Your job: help users find properties to buy or rent, answer questions about the
            buying/renting process, and connect serious buyers with our human agents.

            STYLE
            - Warm, concise, professional. Use short paragraphs.
            - Open with: "Hi! I'm Aria from EstateHub. What are you looking for today?"
              (only if the conversation just started).
            - Speak in the user's language if it's clearly not English.
            - Quote prices in INR with formatting like ₹85,00,000 or ₹1.2 Cr.

            TOOLS
            - Use search_properties whenever the user wants to see listings.
            - Use get_property_details when they ask "tell me more about #5" etc.
            - Use capture_lead AFTER they share their name + phone/email AND agree to follow up.
              Never ask for personal details on the first turn.
            - Use schedule_viewing only after confirming property + date/time + contact.

            BOUNDARIES
            - You can answer general FAQs about home loans, registration, stamp duty,
              and the buying process at a high level.
            - For binding legal/financial advice or specific quotes, always offer to
              connect them with an EstateHub agent.
            - Never invent property listings — only show what search_properties returns.
            """;

    public ChatResponse chat(String sessionId, String userMessage) {
        if (apiKey == null || apiKey.isBlank()) {
            return new ChatResponse(
                "The AI assistant is offline (ANTHROPIC_API_KEY not set on the server). " +
                "Please contact us at hello@estatehub.com and we'll help you directly.",
                sessionId, List.of());
        }

        List<Map<String, Object>> history = sessions.computeIfAbsent(sessionId, k -> new ArrayList<>());
        history.add(Map.of("role", "user", "content", userMessage));

        List<Object> attachments = new ArrayList<>();
        String finalText = "";

        for (int loop = 0; loop < MAX_TOOL_LOOPS; loop++) {
            JsonNode response;
            try {
                response = claude.createMessage(SYSTEM_PROMPT, history);
            } catch (Exception e) {
                log.error("Claude API error", e);
                return new ChatResponse(
                    "Sorry, I'm having trouble connecting right now. Please try again in a moment.",
                    sessionId, List.of());
            }

            JsonNode content = response.path("content");
            String stopReason = response.path("stop_reason").asText("");

            // Append assistant turn to history (full content array preserved for tool_use cycles)
            history.add(Map.of("role", "assistant", "content", jsonNodeToList(content)));

            // Collect text + tool_use blocks
            StringBuilder textBuf = new StringBuilder();
            List<Map<String, Object>> toolResults = new ArrayList<>();

            for (JsonNode block : content) {
                String type = block.path("type").asText();
                if ("text".equals(type)) {
                    textBuf.append(block.path("text").asText()).append(" ");
                } else if ("tool_use".equals(type)) {
                    String toolName = block.path("name").asText();
                    String toolUseId = block.path("id").asText();
                    JsonNode input = block.path("input");
                    log.info("Claude tool call: {} input={}", toolName, input);

                    ToolOutcome outcome = executeTool(toolName, input);
                    if (outcome.attachment != null) attachments.add(outcome.attachment);

                    toolResults.add(Map.of(
                        "type", "tool_result",
                        "tool_use_id", toolUseId,
                        "content", outcome.resultText
                    ));
                }
            }

            if ("end_turn".equals(stopReason) || "stop_sequence".equals(stopReason)) {
                finalText = textBuf.toString().trim();
                break;
            }
            if ("tool_use".equals(stopReason)) {
                // Feed tool results back as a user message
                history.add(Map.of("role", "user", "content", toolResults));
                continue;
            }
            // max_tokens or unknown — return whatever text we have
            finalText = textBuf.toString().trim();
            break;
        }

        if (finalText.isBlank()) finalText = "How can I help you next?";
        return new ChatResponse(finalText, sessionId, attachments);
    }

    private List<Map<String, Object>> jsonNodeToList(JsonNode arr) {
        List<Map<String, Object>> result = new ArrayList<>();
        for (JsonNode node : arr) {
            Map<String, Object> obj = new HashMap<>();
            node.fields().forEachRemaining(e -> obj.put(e.getKey(), jsonNodeToObject(e.getValue())));
            result.add(obj);
        }
        return result;
    }

    private Object jsonNodeToObject(JsonNode n) {
        if (n.isTextual()) return n.asText();
        if (n.isInt()) return n.asInt();
        if (n.isLong()) return n.asLong();
        if (n.isDouble()) return n.asDouble();
        if (n.isBoolean()) return n.asBoolean();
        if (n.isArray()) {
            List<Object> list = new ArrayList<>();
            n.forEach(item -> list.add(jsonNodeToObject(item)));
            return list;
        }
        if (n.isObject()) {
            Map<String, Object> map = new HashMap<>();
            n.fields().forEachRemaining(e -> map.put(e.getKey(), jsonNodeToObject(e.getValue())));
            return map;
        }
        return null;
    }

    /** Execute a Claude-requested tool and return text + an optional UI attachment. */
    private ToolOutcome executeTool(String name, JsonNode input) {
        try {
            return switch (name) {
                case "search_properties" -> runSearch(input);
                case "get_property_details" -> runDetails(input);
                case "capture_lead" -> runCaptureLead(input);
                case "schedule_viewing" -> runScheduleViewing(input);
                default -> new ToolOutcome("Unknown tool: " + name, null);
            };
        } catch (Exception e) {
            log.error("Tool execution failed: {}", name, e);
            return new ToolOutcome("Error running " + name + ": " + e.getMessage(), null);
        }
    }

    private ToolOutcome runSearch(JsonNode in) {
        String city = textOrNull(in, "city");
        String type = textOrNull(in, "type");
        String listing = textOrNull(in, "listing_type");
        Integer minBeds = in.has("min_bedrooms") ? in.get("min_bedrooms").asInt() : null;
        BigDecimal minPrice = in.has("min_price_inr") ? new BigDecimal(in.get("min_price_inr").asText()) : null;
        BigDecimal maxPrice = in.has("max_price_inr") ? new BigDecimal(in.get("max_price_inr").asText()) : null;

        List<Property> results = propertyService.search(city, type, listing, minBeds, minPrice, maxPrice, 8);

        if (results.isEmpty()) {
            return new ToolOutcome(
                "No properties matched those filters. Try widening the budget or city.",
                null);
        }

        StringBuilder sb = new StringBuilder("Found " + results.size() + " matching properties:\n");
        for (Property p : results) {
            sb.append(String.format("• #%d %s — %s, %s | %s BHK | %s sqft | ₹%s%n",
                p.getId(), p.getTitle(), p.getLocality() != null ? p.getLocality() : "", p.getCity(),
                p.getBedrooms(), p.getAreaSqft(), formatPrice(p.getPriceInr())));
        }
        return new ToolOutcome(sb.toString(),
                Map.of("kind", "property_list", "items", results));
    }

    private ToolOutcome runDetails(JsonNode in) {
        Long id = in.get("property_id").asLong();
        return propertyService.findById(id)
            .map(p -> new ToolOutcome(
                "Property #" + p.getId() + ": " + p.getTitle() + "\n" +
                p.getDescription() + "\nPrice: ₹" + formatPrice(p.getPriceInr()) +
                "\nLocation: " + p.getLocality() + ", " + p.getCity() +
                "\nBHK: " + p.getBedrooms() + " | Area: " + p.getAreaSqft() + " sqft" +
                "\nAmenities: " + p.getAmenities(),
                Map.of("kind", "property_detail", "item", p)))
            .orElse(new ToolOutcome("Property #" + id + " not found.", null));
    }

    private ToolOutcome runCaptureLead(JsonNode in) {
        LeadRequest req = new LeadRequest();
        req.setName(textOrNull(in, "name"));
        req.setEmail(textOrNull(in, "email"));
        req.setPhone(textOrNull(in, "phone"));
        req.setRequirement(textOrNull(in, "requirement"));
        req.setSource("chatbot");
        if (in.has("property_id")) req.setPropertyId(in.get("property_id").asLong());
        var saved = leadService.create(req);
        return new ToolOutcome(
            "Lead saved (id=" + saved.getId() + "). Tell the user an agent will reach out within 24 hours.",
            Map.of("kind", "lead_confirmation", "leadId", saved.getId()));
    }

    private ToolOutcome runScheduleViewing(JsonNode in) {
        ViewingRequest req = new ViewingRequest();
        req.setPropertyId(in.get("property_id").asLong());
        req.setCustomerName(in.get("customer_name").asText());
        req.setCustomerPhone(in.get("customer_phone").asText());
        req.setCustomerEmail(textOrNull(in, "customer_email"));
        req.setScheduledAt(LocalDateTime.parse(in.get("scheduled_at").asText()));
        req.setNotes(textOrNull(in, "notes"));
        var saved = viewingService.schedule(req);
        return new ToolOutcome(
            "Viewing scheduled (id=" + saved.getId() + ", at=" + saved.getScheduledAt() +
            "). Confirm the appointment with the user.",
            Map.of("kind", "viewing_confirmation", "viewingId", saved.getId(),
                   "scheduledAt", saved.getScheduledAt().toString()));
    }

    private String textOrNull(JsonNode n, String field) {
        return n.has(field) && !n.get(field).isNull() ? n.get(field).asText() : null;
    }

    private String formatPrice(BigDecimal v) {
        if (v == null) return "-";
        long n = v.longValue();
        if (n >= 10_000_000) return String.format("%.2f Cr", n / 1.0e7);
        if (n >= 100_000)    return String.format("%.2f L", n / 1.0e5);
        return v.toPlainString();
    }

    private record ToolOutcome(String resultText, Object attachment) {}
}
