package com.estatehub.service;

import com.estatehub.tools.ChatbotTools;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Thin wrapper around the Anthropic /v1/messages endpoint. */
@Component
@RequiredArgsConstructor
@Slf4j
public class ClaudeApiClient {

    private final WebClient anthropicWebClient;

    @Value("${anthropic.model}")
    private String model;

    @Value("${anthropic.max-tokens}")
    private int maxTokens;

    /**
     * Send the conversation to Claude with the EstateHub tool set and return the raw
     * response JSON. Caller is responsible for handling tool_use blocks and looping.
     */
    public JsonNode createMessage(String systemPrompt, List<Map<String, Object>> messages) {
        Map<String, Object> body = new HashMap<>();
        body.put("model", model);
        body.put("max_tokens", maxTokens);
        body.put("system", systemPrompt);
        body.put("messages", messages);
        body.put("tools", ChatbotTools.definitions());

        return anthropicWebClient.post()
                .bodyValue(body)
                .retrieve()
                .bodyToMono(JsonNode.class)
                .block(Duration.ofSeconds(60));
    }
}
