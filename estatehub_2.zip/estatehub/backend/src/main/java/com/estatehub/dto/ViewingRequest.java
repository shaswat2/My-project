package com.estatehub.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class ViewingRequest {
    @NotNull
    private Long propertyId;

    @NotBlank
    private String customerName;

    @NotBlank
    private String customerPhone;

    private String customerEmail;

    @NotNull
    private LocalDateTime scheduledAt;

    private String notes;
}
