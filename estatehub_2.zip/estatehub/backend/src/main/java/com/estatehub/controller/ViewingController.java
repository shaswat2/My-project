package com.estatehub.controller;

import com.estatehub.dto.ViewingRequest;
import com.estatehub.model.Viewing;
import com.estatehub.service.ViewingService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/viewings")
@RequiredArgsConstructor
public class ViewingController {

    private final ViewingService service;

    @PostMapping
    public Viewing schedule(@Valid @RequestBody ViewingRequest req) {
        return service.schedule(req);
    }

    @GetMapping
    public List<Viewing> list() {
        return service.findAll();
    }
}
