package com.estatehub.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.util.List;

public class ChatDtos {

    @Data
    public static class ChatRequest {
        @NotBlank
        private String sessionId;
        @NotBlank
        private String message;
    }

    @Data
    public static class ChatResponse {
        private String reply;
        private String sessionId;
        private List<Object> attachments; // structured cards (properties, viewings)

        public ChatResponse(String reply, String sessionId, List<Object> attachments) {
            this.reply = reply;
            this.sessionId = sessionId;
            this.attachments = attachments;
        }
    }
}
