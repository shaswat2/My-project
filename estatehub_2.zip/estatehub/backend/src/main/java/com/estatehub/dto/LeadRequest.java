package com.estatehub.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class LeadRequest {
    @NotBlank
    private String name;

    @Email
    private String email;

    @NotBlank
    private String phone;

    private String requirement;
    private Long propertyId;
    private String source;
}
