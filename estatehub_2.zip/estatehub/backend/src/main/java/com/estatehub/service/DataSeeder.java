package com.estatehub.service;

import com.estatehub.model.Property;
import com.estatehub.repository.PropertyRepository;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class DataSeeder {

    private final PropertyRepository propertyRepository;

    @PostConstruct
    public void seed() {
        if (propertyRepository.count() > 0) return;

        List<Property> seed = List.of(
            Property.builder().title("Luxury 3BHK with Sea View")
                .description("Premium 3BHK apartment overlooking the Arabian Sea. Modular kitchen, " +
                        "Italian marble flooring, panoramic balcony. Walking distance to Bandra station.")
                .city("Mumbai").locality("Bandra West").type("APARTMENT").listingType("SALE")
                .bedrooms(3).bathrooms(3).areaSqft(1850.0).priceInr(new BigDecimal("45000000"))
                .imageUrl("https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800&q=80")
                .amenities("Pool,Gym,24x7 Security,Covered Parking,Power Backup,Club House")
                .featured(true).build(),

            Property.builder().title("Modern 2BHK near OMR")
                .description("Brand-new 2BHK in a gated community. Close to IT corridor, schools, hospitals. " +
                        "Excellent investment for young professionals.")
                .city("Chennai").locality("Sholinganallur").type("APARTMENT").listingType("SALE")
                .bedrooms(2).bathrooms(2).areaSqft(1180.0).priceInr(new BigDecimal("8500000"))
                .imageUrl("https://images.unsplash.com/photo-1568605114967-8130f3a36994?w=800&q=80")
                .amenities("Gym,Children's Play Area,24x7 Security,Power Backup,Lift")
                .featured(true).build(),

            Property.builder().title("Spacious 4BHK Villa with Garden")
                .description("Independent villa with landscaped garden, private parking for 2 cars, " +
                        "and rooftop terrace. Quiet residential locality.")
                .city("Bangalore").locality("Whitefield").type("VILLA").listingType("SALE")
                .bedrooms(4).bathrooms(4).areaSqft(3200.0).priceInr(new BigDecimal("32500000"))
                .imageUrl("https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80")
                .amenities("Private Garden,Rooftop Terrace,Servant Quarters,Modular Kitchen,Solar Panels")
                .featured(true).build(),

            Property.builder().title("Cozy 1BHK for Rent")
                .description("Fully furnished 1BHK in a peaceful neighborhood. Ideal for working " +
                        "professionals or couples. Close to metro station.")
                .city("Bangalore").locality("Indiranagar").type("APARTMENT").listingType("RENT")
                .bedrooms(1).bathrooms(1).areaSqft(680.0).priceInr(new BigDecimal("28000"))
                .imageUrl("https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800&q=80")
                .amenities("Furnished,WiFi,Power Backup,24x7 Security,Lift")
                .featured(false).build(),

            Property.builder().title("Premium 3BHK Penthouse")
                .description("Top-floor penthouse with private terrace, jacuzzi, and 360° city views. " +
                        "Luxury fittings throughout.")
                .city("Hyderabad").locality("Gachibowli").type("APARTMENT").listingType("SALE")
                .bedrooms(3).bathrooms(3).areaSqft(2400.0).priceInr(new BigDecimal("21000000"))
                .imageUrl("https://images.unsplash.com/photo-1493809842364-78817add7ffb?w=800&q=80")
                .amenities("Private Terrace,Jacuzzi,Smart Home,Pool,Gym,Concierge")
                .featured(true).build(),

            Property.builder().title("Affordable 2BHK Family Home")
                .description("Well-maintained 2BHK in a family-friendly area. Schools, parks, and " +
                        "metro within 1km. Perfect first home.")
                .city("Pune").locality("Kothrud").type("APARTMENT").listingType("SALE")
                .bedrooms(2).bathrooms(2).areaSqft(1050.0).priceInr(new BigDecimal("7800000"))
                .imageUrl("https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&q=80")
                .amenities("Park View,Children's Play Area,Lift,Power Backup,Parking")
                .featured(false).build(),

            Property.builder().title("Commercial Office Space")
                .description("Grade-A office space in central business district. Ready-to-move-in " +
                        "with HVAC, false ceiling, and ample parking.")
                .city("Mumbai").locality("BKC").type("COMMERCIAL").listingType("RENT")
                .bedrooms(0).bathrooms(2).areaSqft(2500.0).priceInr(new BigDecimal("450000"))
                .imageUrl("https://images.unsplash.com/photo-1497366216548-37526070297c?w=800&q=80")
                .amenities("HVAC,Power Backup,High-speed Lifts,Cafeteria,Conference Rooms")
                .featured(false).build(),

            Property.builder().title("Residential Plot - 2400 sqft")
                .description("Corner plot in approved layout. Clear title, ready for construction. " +
                        "Good appreciation potential.")
                .city("Chennai").locality("ECR").type("PLOT").listingType("SALE")
                .bedrooms(0).bathrooms(0).areaSqft(2400.0).priceInr(new BigDecimal("18000000"))
                .imageUrl("https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800&q=80")
                .amenities("Corner Plot,Clear Title,Approved Layout,Wide Roads,Compound Wall")
                .featured(false).build(),

            Property.builder().title("Studio Apartment for Rent")
                .description("Modern studio with full kitchenette, work nook, and city views. " +
                        "Great for singles or couples.")
                .city("Mumbai").locality("Powai").type("APARTMENT").listingType("RENT")
                .bedrooms(1).bathrooms(1).areaSqft(450.0).priceInr(new BigDecimal("32000"))
                .imageUrl("https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800&q=80")
                .amenities("Furnished,Lake View,Gym,Pool,Power Backup")
                .featured(false).build(),

            Property.builder().title("Independent House with Parking")
                .description("Two-storey independent house with 4 bedrooms, parking for 2 cars, " +
                        "and a small garden. Quiet residential street.")
                .city("Hyderabad").locality("Jubilee Hills").type("INDEPENDENT_HOUSE").listingType("SALE")
                .bedrooms(4).bathrooms(4).areaSqft(2800.0).priceInr(new BigDecimal("28000000"))
                .imageUrl("https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800&q=80")
                .amenities("Garden,Parking,Modular Kitchen,Borewell,Inverter")
                .featured(true).build(),

            Property.builder().title("Lakeside 2BHK Apartment")
                .description("Stunning 2BHK with lake-facing balcony. Modern fittings, two-tier " +
                        "security, and resort-style amenities.")
                .city("Bangalore").locality("Whitefield").type("APARTMENT").listingType("SALE")
                .bedrooms(2).bathrooms(2).areaSqft(1320.0).priceInr(new BigDecimal("11500000"))
                .imageUrl("https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800&q=80")
                .amenities("Lake View,Pool,Gym,Tennis Court,Club House,24x7 Security")
                .featured(false).build(),

            Property.builder().title("Heritage Bungalow")
                .description("Restored colonial-era bungalow on 5400 sqft plot. Original wood floors, " +
                        "high ceilings, modern updates throughout.")
                .city("Pune").locality("Koregaon Park").type("INDEPENDENT_HOUSE").listingType("SALE")
                .bedrooms(5).bathrooms(5).areaSqft(4200.0).priceInr(new BigDecimal("65000000"))
                .imageUrl("https://images.unsplash.com/photo-1580587771525-78b9dba3b914?w=800&q=80")
                .amenities("Heritage Property,Garden,Servant Quarters,Original Wood Floors,Wine Cellar")
                .featured(true).build()
        );

        propertyRepository.saveAll(seed);
        log.info("Seeded {} properties.", seed.size());
    }
}
