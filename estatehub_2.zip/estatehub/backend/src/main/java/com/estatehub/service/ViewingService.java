package com.estatehub.service;

import com.estatehub.dto.ViewingRequest;
import com.estatehub.model.Viewing;
import com.estatehub.repository.ViewingRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class ViewingService {

    private final ViewingRepository repository;

    public Viewing schedule(ViewingRequest req) {
        Viewing viewing = Viewing.builder()
                .propertyId(req.getPropertyId())
                .customerName(req.getCustomerName())
                .customerPhone(req.getCustomerPhone())
                .customerEmail(req.getCustomerEmail())
                .scheduledAt(req.getScheduledAt())
                .notes(req.getNotes())
                .status("REQUESTED")
                .build();
        Viewing saved = repository.save(viewing);
        log.info("Viewing scheduled: id={}, property={}, at={}",
                saved.getId(), saved.getPropertyId(), saved.getScheduledAt());
        return saved;
    }

    public List<Viewing> findAll() {
        return repository.findAll();
    }
}
