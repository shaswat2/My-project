package com.estatehub.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;
import java.time.LocalDateTime;

@Entity
@Table(name = "viewings")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Viewing {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long propertyId;
    private String customerName;
    private String customerPhone;
    private String customerEmail;
    private LocalDateTime scheduledAt;
    private String status;          // REQUESTED, CONFIRMED, COMPLETED, CANCELLED

    @Column(length = 1000)
    private String notes;

    private Instant createdAt;

    @PrePersist
    void onCreate() {
        this.createdAt = Instant.now();
        if (status == null) status = "REQUESTED";
    }
}
