package com.estatehub.controller;

import com.estatehub.dto.ChatDtos;
import com.estatehub.service.ChatService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/chat")
@RequiredArgsConstructor
public class ChatController {

    private final ChatService chatService;

    @PostMapping
    public ChatDtos.ChatResponse chat(@Valid @RequestBody ChatDtos.ChatRequest req) {
        return chatService.chat(req.getSessionId(), req.getMessage());
    }
}
