package com.estatehub.controller;

import com.estatehub.dto.LeadRequest;
import com.estatehub.model.Lead;
import com.estatehub.service.LeadService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/leads")
@RequiredArgsConstructor
public class LeadController {

    private final LeadService service;

    @PostMapping
    public Lead create(@Valid @RequestBody LeadRequest req) {
        return service.create(req);
    }

    @GetMapping
    public List<Lead> list() {
        return service.findAll();
    }
}
