package com.estatehub.tools;

import java.util.List;
import java.util.Map;

/**
 * Tool definitions exposed to Claude. Each tool has a name, description, and JSON-schema
 * input. Claude decides when to call them based on the user's request.
 */
public final class ChatbotTools {

    private ChatbotTools() {}

    public static List<Map<String, Object>> definitions() {
        return List.of(
                searchProperties(),
                getPropertyDetails(),
                captureLead(),
                scheduleViewing()
        );
    }

    private static Map<String, Object> searchProperties() {
        return Map.of(
            "name", "search_properties",
            "description", "Search EstateHub's property listings using filters. " +
                    "Use this whenever the user asks to find / browse / show / recommend properties.",
            "input_schema", Map.of(
                "type", "object",
                "properties", Map.of(
                    "city", Map.of("type", "string",
                            "description", "City name, e.g. 'Chennai', 'Bangalore', 'Mumbai'."),
                    "type", Map.of("type", "string",
                            "enum", List.of("APARTMENT", "VILLA", "PLOT", "INDEPENDENT_HOUSE", "COMMERCIAL"),
                            "description", "Property type."),
                    "listing_type", Map.of("type", "string",
                            "enum", List.of("SALE", "RENT"),
                            "description", "Whether the property is for sale or rent."),
                    "min_bedrooms", Map.of("type", "integer",
                            "description", "Minimum number of bedrooms (BHK)."),
                    "min_price_inr", Map.of("type", "number",
                            "description", "Minimum price in INR."),
                    "max_price_inr", Map.of("type", "number",
                            "description", "Maximum budget in INR.")
                ),
                "required", List.of()
            )
        );
    }

    private static Map<String, Object> getPropertyDetails() {
        return Map.of(
            "name", "get_property_details",
            "description", "Fetch full details of one property by its ID. Use after the user " +
                    "asks for more info on a specific listing.",
            "input_schema", Map.of(
                "type", "object",
                "properties", Map.of(
                    "property_id", Map.of("type", "integer",
                            "description", "The numeric property ID.")
                ),
                "required", List.of("property_id")
            )
        );
    }

    private static Map<String, Object> captureLead() {
        return Map.of(
            "name", "capture_lead",
            "description", "Save the user's contact details so an EstateHub agent can follow up. " +
                    "Call this only after the user has explicitly shared their name and at least " +
                    "an email or phone, and has agreed to be contacted.",
            "input_schema", Map.of(
                "type", "object",
                "properties", Map.of(
                    "name", Map.of("type", "string"),
                    "email", Map.of("type", "string"),
                    "phone", Map.of("type", "string"),
                    "requirement", Map.of("type", "string",
                            "description", "Short summary of what the user is looking for."),
                    "property_id", Map.of("type", "integer",
                            "description", "Optional: the property they're interested in.")
                ),
                "required", List.of("name", "phone")
            )
        );
    }

    private static Map<String, Object> scheduleViewing() {
        return Map.of(
            "name", "schedule_viewing",
            "description", "Book an in-person property viewing. Confirm the date/time, " +
                    "property, and contact details with the user before calling this.",
            "input_schema", Map.of(
                "type", "object",
                "properties", Map.of(
                    "property_id", Map.of("type", "integer"),
                    "customer_name", Map.of("type", "string"),
                    "customer_phone", Map.of("type", "string"),
                    "customer_email", Map.of("type", "string"),
                    "scheduled_at", Map.of("type", "string",
                            "description", "ISO-8601 local datetime, e.g. '2025-11-15T15:30:00'."),
                    "notes", Map.of("type", "string")
                ),
                "required", List.of("property_id", "customer_name", "customer_phone", "scheduled_at")
            )
        );
    }
}
