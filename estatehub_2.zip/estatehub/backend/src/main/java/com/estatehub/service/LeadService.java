package com.estatehub.service;

import com.estatehub.dto.LeadRequest;
import com.estatehub.model.Lead;
import com.estatehub.repository.LeadRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class LeadService {

    private final LeadRepository repository;

    public Lead create(LeadRequest req) {
        Lead lead = Lead.builder()
                .name(req.getName())
                .email(req.getEmail())
                .phone(req.getPhone())
                .requirement(req.getRequirement())
                .propertyId(req.getPropertyId())
                .source(req.getSource() != null ? req.getSource() : "contact-form")
                .build();
        Lead saved = repository.save(lead);
        log.info("New lead captured: id={}, name={}, source={}",
                saved.getId(), saved.getName(), saved.getSource());
        return saved;
    }

    public List<Lead> findAll() {
        return repository.findAll();
    }
}
