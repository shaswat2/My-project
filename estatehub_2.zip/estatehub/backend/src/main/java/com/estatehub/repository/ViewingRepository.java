package com.estatehub.repository;

import com.estatehub.model.Viewing;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ViewingRepository extends JpaRepository<Viewing, Long> {
}
