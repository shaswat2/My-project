# EstateHub — Real Estate Management Platform

A full-stack real estate platform with an AI assistant ("Aria") that helps users find
properties, schedule viewings, and capture leads — all powered by Claude with tool use.

## Stack

| Layer | Tech |
|---|---|
| Backend | Java 17, Spring Boot 3.3, Spring Data JPA, WebFlux |
| Database | H2 (file-based, default) — switch to MySQL with one config change |
| AI | Anthropic Claude API (tool use / function calling) |
| Frontend | React 18, Vite, React Router, Axios, Lucide icons |
| Styling | Custom CSS design system (no Tailwind needed) |

## Features

- **Property listings** with search, filters, detail pages, image gallery
- **AI chat assistant Aria** — natural language search, recommendations, lead capture, viewing scheduling
- **Lead capture form** on every property page
- **Viewing scheduler** — Aria books in-person visits via the chatbot
- **REST API** — full CRUD for properties, leads, viewings
- **Pre-seeded data** — 12 realistic properties across Indian cities
- **Modern responsive UI** — gradient hero, smooth animations, mobile-friendly chat widget

## Prerequisites

- **Java 17+** (`java -version`)
- **Maven 3.8+** (`mvn -version`)
- **Node 18+** and npm (`node -v`)
- **Anthropic API key** — get one at https://console.anthropic.com (required for the chatbot)

## Quick Start

### 1. Clone / extract this folder

```bash
cd estatehub
```

### 2. Set your Anthropic API key

```bash
# macOS / Linux
export ANTHROPIC_API_KEY=sk-ant-your-key-here

# Windows (PowerShell)
$env:ANTHROPIC_API_KEY="sk-ant-your-key-here"
```

> Without this, the rest of the site works but the AI chatbot will say it's offline.

### 3. Run the backend

```bash
cd backend
mvn spring-boot:run
```

> If you don't have Maven installed: download it from https://maven.apache.org/download.cgi
> (or `brew install maven` on macOS, `sudo apt install maven` on Ubuntu, `choco install maven` on Windows).

Wait for `Started EstateHubApplication` — backend now runs on **http://localhost:8080**.
Sample properties are seeded automatically on first run.

The H2 console (browse the SQL DB) is at **http://localhost:8080/h2-console**
(JDBC URL: `jdbc:h2:file:./data/estatehub`, username `sa`, no password).

### 4. Run the frontend

In a **new terminal**:

```bash
cd frontend
npm install
npm run dev
```

Frontend runs on **http://localhost:5173** — open it in your browser.

### 5. Try it out

- Browse the home page → click featured properties
- Use the search bar in the hero
- Filter properties on `/properties`
- Click the **floating blue chat button** (bottom right) → talk to Aria:
  - *"Show me 2BHK apartments in Bangalore under ₹1Cr"*
  - *"I want a villa for sale in Hyderabad"*
  - *"Tell me more about property #3"*
  - *"My name is Priya, phone 9876543210, please have someone call me"*

## Switching to MySQL

When you're ready to use a real database, edit `backend/src/main/resources/application.properties`:

1. Comment out the H2 block
2. Uncomment the MySQL block and set your password
3. Make sure MySQL is running locally (port 3306) and create the database — or let
   `createDatabaseIfNotExist=true` in the URL handle it

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/estatehub?createDatabaseIfNotExist=true&useSSL=false&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=your_password
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
spring.jpa.database-platform=org.hibernate.dialect.MySQL8Dialect
spring.jpa.hibernate.ddl-auto=update
```

Restart the backend. Tables are created automatically by Hibernate.

## Project Structure

```
estatehub/
├── backend/                              Spring Boot
│   ├── pom.xml
│   └── src/main/
│       ├── java/com/estatehub/
│       │   ├── EstateHubApplication.java
│       │   ├── config/                   CORS + Anthropic WebClient
│       │   ├── controller/               REST endpoints
│       │   ├── service/                  ChatService, ClaudeApiClient, etc.
│       │   ├── tools/                    Claude tool definitions
│       │   ├── model/                    JPA entities
│       │   ├── repository/               Spring Data repos
│       │   └── dto/                      Request/response DTOs
│       └── resources/application.properties
└── frontend/                             React + Vite
    ├── package.json
    ├── vite.config.js
    └── src/
        ├── App.jsx                       Router + layout
        ├── components/                   Navbar, Footer, ChatWidget, PropertyCard
        ├── pages/                        Home, Properties, PropertyDetail, About, Contact
        ├── services/api.js               Axios client
        └── styles/                       global.css + chat.css
```

## API Reference

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/properties` | List/search properties (query params: city, type, listingType, minBedrooms, maxPrice) |
| GET | `/api/properties/featured` | Featured listings only |
| GET | `/api/properties/{id}` | Single property |
| POST | `/api/properties` | Create (admin) |
| PUT | `/api/properties/{id}` | Update (admin) |
| DELETE | `/api/properties/{id}` | Delete (admin) |
| POST | `/api/leads` | Submit a contact form / lead |
| GET | `/api/leads` | List all leads (admin) |
| POST | `/api/viewings` | Schedule a viewing |
| POST | `/api/chat` | Send a message to Aria — body: `{ sessionId, message }` |

## How the AI works

When you message Aria, the flow is:

1. React → `POST /api/chat` with `sessionId` + message
2. Spring Boot adds the user's message to per-session history
3. Sends history + system prompt + 4 **tool definitions** to Claude:
   - `search_properties` — Claude calls this to query your DB
   - `get_property_details`
   - `capture_lead` — saves to the `leads` table
   - `schedule_viewing` — saves to the `viewings` table
4. If Claude wants to call a tool, the backend executes it locally, feeds the result back,
   and Claude generates a natural language reply
5. The reply (plus structured property cards as `attachments`) is returned to React
6. React renders the text + clickable property cards inline in the chat

This is **far more capable** than rule-based bots — Claude understands intent,
asks clarifying questions, and decides which tool to call when.

## Deployment notes

- **Backend**: build a JAR with `mvn clean package`, deploy to anywhere (AWS ECS, DigitalOcean,
  Render). Set `ANTHROPIC_API_KEY` and your DB credentials as environment variables.
- **Frontend**: run `npm run build` → static files in `dist/`. Host on Vercel, Netlify, S3+CloudFront, etc.
- **CORS**: update `cors.allowed-origins` in `application.properties` to your production frontend URL.
- **DB**: switch to MySQL/PostgreSQL for production; H2 is fine for dev.
- **Sessions**: chat history is in-memory — for multi-instance prod, swap the `sessions` map
  in `ChatService` for Redis.

## Cost guide

Claude API usage for this app is small. Each chatbot turn typically costs less than $0.01.
For a quote, see https://www.anthropic.com/pricing.

## License

MIT — yours to extend.
