import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  timeout: 90000,
  headers: { 'Content-Type': 'application/json' },
})

// ─── Properties ────────────────────────────────────────────────────────────
export const fetchProperties = (params = {}) =>
  api.get('/properties', { params }).then((r) => r.data)

export const fetchFeaturedProperties = () =>
  api.get('/properties/featured').then((r) => r.data)

export const fetchProperty = (id) =>
  api.get(`/properties/${id}`).then((r) => r.data)

// ─── Leads ─────────────────────────────────────────────────────────────────
export const submitLead = (payload) =>
  api.post('/leads', payload).then((r) => r.data)

// ─── Chat ──────────────────────────────────────────────────────────────────
export const sendChatMessage = (sessionId, message) =>
  api.post('/chat', { sessionId, message }).then((r) => r.data)

export default api
