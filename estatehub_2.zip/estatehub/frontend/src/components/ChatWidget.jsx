import { useState, useRef, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { MessageCircle, X, Send, Sparkles } from 'lucide-react'
import { sendChatMessage } from '../services/api'
import { formatPrice } from './PropertyCard'
import '../styles/chat.css'

const SUGGESTIONS = [
  'Show me 2BHK in Bangalore under ₹1Cr',
  'I want a villa for sale',
  'Properties for rent in Mumbai',
  'Help me schedule a viewing',
]

const sessionId = (() => {
  const k = 'estatehub_session'
  let id = sessionStorage.getItem(k)
  if (!id) {
    id = `s_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`
    sessionStorage.setItem(k, id)
  }
  return id
})()

export default function ChatWidget() {
  const [open, setOpen] = useState(false)
  const [showTip, setShowTip] = useState(true)
  const [messages, setMessages] = useState([
    {
      role: 'bot',
      text: "Hi! I'm Aria from EstateHub. What are you looking for today? 🏡",
    },
  ])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const scrollRef = useRef(null)
  const textareaRef = useRef(null)

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [messages, loading])

  useEffect(() => {
    const t = setTimeout(() => setShowTip(false), 8000)
    return () => clearTimeout(t)
  }, [])

  async function handleSend(textOverride) {
    const text = (textOverride ?? input).trim()
    if (!text || loading) return
    setInput('')
    setMessages((m) => [...m, { role: 'user', text }])
    setLoading(true)

    try {
      const res = await sendChatMessage(sessionId, text)
      const newMessages = [{ role: 'bot', text: res.reply }]

      // Render structured attachments (property cards)
      if (Array.isArray(res.attachments)) {
        for (const att of res.attachments) {
          if (att?.kind === 'property_list' && Array.isArray(att.items)) {
            newMessages.push({ role: 'attachment', items: att.items })
          } else if (att?.kind === 'property_detail' && att.item) {
            newMessages.push({ role: 'attachment', items: [att.item] })
          }
        }
      }
      setMessages((m) => [...m, ...newMessages])
    } catch (err) {
      setMessages((m) => [
        ...m,
        { role: 'bot', text: "Sorry, something went wrong. Please try again.", error: true },
      ])
    } finally {
      setLoading(false)
      textareaRef.current?.focus()
    }
  }

  function handleKeyDown(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  if (!open) {
    return (
      <button className="chat-launcher" onClick={() => { setOpen(true); setShowTip(false) }}>
        {showTip && <span className="chat-launcher-tooltip">Hey! Looking for a home? 👋</span>}
        <MessageCircle size={28} />
      </button>
    )
  }

  return (
    <div className="chat-window" role="dialog" aria-label="EstateHub assistant">
      <header className="chat-header">
        <div className="chat-avatar">
          <Sparkles size={18} />
        </div>
        <div className="chat-header-text">
          <h4>Aria</h4>
          <p>EstateHub AI Assistant</p>
        </div>
        <button className="chat-close" onClick={() => setOpen(false)} aria-label="Close chat">
          <X size={18} />
        </button>
      </header>

      <div className="chat-messages" ref={scrollRef}>
        {messages.map((m, i) => {
          if (m.role === 'attachment') {
            return (
              <div key={i} className="chat-attachment">
                {m.items.slice(0, 4).map((p) => (
                  <Link
                    key={p.id}
                    to={`/properties/${p.id}`}
                    className="chat-property-card"
                    onClick={() => setOpen(false)}
                  >
                    <img
                      src={p.imageUrl || 'https://images.unsplash.com/photo-1568605114967-8130f3a36994?w=200'}
                      alt=""
                    />
                    <div className="chat-property-card-body">
                      <div className="chat-property-card-title">{p.title}</div>
                      <div className="chat-property-card-price">
                        {formatPrice(p.priceInr, p.listingType)}
                      </div>
                      <div className="chat-property-card-meta">
                        {p.bedrooms ? `${p.bedrooms} BHK · ` : ''}{p.locality || p.city}
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )
          }
          return (
            <div key={i} className={`chat-msg ${m.role} ${m.error ? 'error' : ''}`}>
              {m.text}
            </div>
          )
        })}
        {loading && (
          <div className="chat-typing">
            <span></span><span></span><span></span>
          </div>
        )}
      </div>

      {messages.length <= 1 && !loading && (
        <div className="chat-suggestions">
          {SUGGESTIONS.map((s, i) => (
            <button key={i} className="chat-suggestion" onClick={() => handleSend(s)}>
              {s}
            </button>
          ))}
        </div>
      )}

      <div className="chat-input-row">
        <textarea
          ref={textareaRef}
          rows={1}
          placeholder="Type your message..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          disabled={loading}
        />
        <button
          className="chat-send-btn"
          onClick={() => handleSend()}
          disabled={loading || !input.trim()}
          aria-label="Send"
        >
          <Send size={16} />
        </button>
      </div>
    </div>
  )
}
