import { NavLink, Link } from 'react-router-dom'
import { Home as HomeIcon } from 'lucide-react'

export default function Navbar() {
  return (
    <nav className="navbar">
      <div className="navbar-inner">
        <Link to="/" className="brand">
          <span className="brand-icon">
            <HomeIcon size={20} />
          </span>
          EstateHub
        </Link>
        <div className="nav-links">
          <NavLink to="/" end className="nav-link">Home</NavLink>
          <NavLink to="/properties" className="nav-link">Properties</NavLink>
          <NavLink to="/about" className="nav-link">About</NavLink>
          <NavLink to="/contact" className="nav-link">Contact</NavLink>
          <Link to="/contact" className="btn btn-primary btn-sm nav-cta">List Your Property</Link>
        </div>
      </div>
    </nav>
  )
}
