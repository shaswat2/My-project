import { Link } from 'react-router-dom'
import { MapPin, Bed, Bath, Maximize2, Heart } from 'lucide-react'

const FALLBACK_IMG = 'https://images.unsplash.com/photo-1568605114967-8130f3a36994?w=800&q=80'

export function formatPrice(value, listingType) {
  if (value == null) return '-'
  const n = Number(value)
  if (listingType === 'RENT') return `₹${n.toLocaleString('en-IN')}/mo`
  if (n >= 1_00_00_000) return `₹${(n / 1_00_00_000).toFixed(2)} Cr`
  if (n >= 1_00_000) return `₹${(n / 1_00_000).toFixed(2)} L`
  return `₹${n.toLocaleString('en-IN')}`
}

export default function PropertyCard({ property }) {
  return (
    <Link to={`/properties/${property.id}`} className="property-card">
      <div className="property-image">
        <img
          src={property.imageUrl || FALLBACK_IMG}
          alt={property.title}
          onError={(e) => (e.currentTarget.src = FALLBACK_IMG)}
        />
        <span className={`property-badge ${property.listingType?.toLowerCase()}`}>
          For {property.listingType === 'RENT' ? 'Rent' : 'Sale'}
        </span>
        <button
          className="property-fav"
          onClick={(e) => { e.preventDefault(); e.stopPropagation() }}
          aria-label="Save"
        >
          <Heart size={16} />
        </button>
      </div>
      <div className="property-body">
        <div className="property-price">
          {formatPrice(property.priceInr, property.listingType)}
          {property.listingType === 'RENT' && <span className="unit"></span>}
        </div>
        <h3 className="property-title">{property.title}</h3>
        <div className="property-location">
          <MapPin size={13} />
          {property.locality ? `${property.locality}, ${property.city}` : property.city}
        </div>
        <div className="property-specs">
          {property.bedrooms > 0 && (
            <span className="property-spec"><Bed size={14} /> <strong>{property.bedrooms}</strong> Beds</span>
          )}
          {property.bathrooms > 0 && (
            <span className="property-spec"><Bath size={14} /> <strong>{property.bathrooms}</strong> Baths</span>
          )}
          {property.areaSqft && (
            <span className="property-spec"><Maximize2 size={14} /> <strong>{property.areaSqft}</strong> sqft</span>
          )}
        </div>
      </div>
    </Link>
  )
}
