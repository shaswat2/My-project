import { Link } from 'react-router-dom'
import { Home as HomeIcon, Mail, Phone, MapPin } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-grid">
        <div className="footer-brand">
          <div className="brand" style={{ color: 'white' }}>
            <span className="brand-icon"><HomeIcon size={20} /></span>
            EstateHub
          </div>
          <p>Your trusted partner for finding the perfect home. Browse thousands of verified listings across India.</p>
        </div>
        <div>
          <h4>Explore</h4>
          <ul>
            <li><Link to="/properties">All Properties</Link></li>
            <li><Link to="/properties?listingType=SALE">For Sale</Link></li>
            <li><Link to="/properties?listingType=RENT">For Rent</Link></li>
            <li><Link to="/about">About Us</Link></li>
          </ul>
        </div>
        <div>
          <h4>Company</h4>
          <ul>
            <li><Link to="/contact">Contact</Link></li>
            <li><a href="#">Careers</a></li>
            <li><a href="#">Privacy</a></li>
            <li><a href="#">Terms</a></li>
          </ul>
        </div>
        <div>
          <h4>Get in Touch</h4>
          <ul>
            <li style={{ display: 'flex', gap: 8, alignItems: 'center' }}><Mail size={14} /> hello@estatehub.com</li>
            <li style={{ display: 'flex', gap: 8, alignItems: 'center' }}><Phone size={14} /> +91 98765 43210</li>
            <li style={{ display: 'flex', gap: 8, alignItems: 'center' }}><MapPin size={14} /> Bangalore, India</li>
          </ul>
        </div>
      </div>
      <div className="footer-bottom">
        <span>© {new Date().getFullYear()} EstateHub. All rights reserved.</span>
        <span>Made with care.</span>
      </div>
    </footer>
  )
}
