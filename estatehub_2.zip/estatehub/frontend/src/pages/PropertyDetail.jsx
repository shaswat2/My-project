import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { MapPin, Bed, Bath, Maximize2, Calendar, Tag } from 'lucide-react'
import { fetchProperty, submitLead } from '../services/api'
import { formatPrice } from '../components/PropertyCard'

const FALLBACK_IMG = 'https://images.unsplash.com/photo-1568605114967-8130f3a36994?w=1600&q=80'

export default function PropertyDetail() {
  const { id } = useParams()
  const [property, setProperty] = useState(null)
  const [loading, setLoading] = useState(true)
  const [form, setForm] = useState({ name: '', email: '', phone: '', requirement: '' })
  const [submitted, setSubmitted] = useState(false)
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    setLoading(true)
    fetchProperty(id)
      .then(setProperty)
      .catch(() => setProperty(null))
      .finally(() => setLoading(false))
  }, [id])

  async function handleSubmit(e) {
    e.preventDefault()
    setSubmitting(true)
    try {
      await submitLead({ ...form, propertyId: Number(id), source: 'property-detail' })
      setSubmitted(true)
      setForm({ name: '', email: '', phone: '', requirement: '' })
    } catch {
      alert('Could not send your enquiry. Please try again.')
    } finally {
      setSubmitting(false)
    }
  }

  if (loading) return <p style={{ padding: 60, textAlign: 'center', color: 'var(--text-muted)' }}>Loading...</p>
  if (!property) return (
    <div className="empty-state">
      <h3>Property not found</h3>
      <p>This listing may have been removed.</p>
    </div>
  )

  const amenities = (property.amenities || '').split(',').map((s) => s.trim()).filter(Boolean)

  return (
    <>
      <div
        className="detail-hero"
        style={{ backgroundImage: `url(${property.imageUrl || FALLBACK_IMG})` }}
      />
      <div className="detail-content">
        <div className="detail-card">
          <div className="detail-main">
            <span className={`property-badge ${property.listingType?.toLowerCase()}`} style={{ position: 'static', display: 'inline-block', marginBottom: 16 }}>
              For {property.listingType === 'RENT' ? 'Rent' : 'Sale'}
            </span>
            <h1>{property.title}</h1>
            <div className="detail-location">
              <MapPin size={16} />
              {property.locality ? `${property.locality}, ${property.city}` : property.city}
            </div>
            <div className="detail-price-large">
              {formatPrice(property.priceInr, property.listingType)}
            </div>

            <div className="detail-specs-grid">
              {property.bedrooms > 0 && (
                <div className="detail-spec">
                  <span className="detail-spec-label"><Bed size={14} style={{ display: 'inline', marginRight: 4 }} />Bedrooms</span>
                  <span className="detail-spec-value">{property.bedrooms}</span>
                </div>
              )}
              {property.bathrooms > 0 && (
                <div className="detail-spec">
                  <span className="detail-spec-label"><Bath size={14} style={{ display: 'inline', marginRight: 4 }} />Bathrooms</span>
                  <span className="detail-spec-value">{property.bathrooms}</span>
                </div>
              )}
              {property.areaSqft && (
                <div className="detail-spec">
                  <span className="detail-spec-label"><Maximize2 size={14} style={{ display: 'inline', marginRight: 4 }} />Area</span>
                  <span className="detail-spec-value">{property.areaSqft} sqft</span>
                </div>
              )}
              <div className="detail-spec">
                <span className="detail-spec-label"><Tag size={14} style={{ display: 'inline', marginRight: 4 }} />Type</span>
                <span className="detail-spec-value" style={{ fontSize: 14 }}>{property.type}</span>
              </div>
            </div>

            <h3 style={{ marginBottom: 12 }}>About this property</h3>
            <p className="detail-description">{property.description}</p>

            {amenities.length > 0 && (
              <>
                <h3 style={{ marginBottom: 12 }}>Amenities</h3>
                <div className="amenities-grid">
                  {amenities.map((a, i) => (
                    <span key={i} className="amenity-pill">{a}</span>
                  ))}
                </div>
              </>
            )}
          </div>

          <aside className="detail-side">
            <h3>Interested? Get in touch</h3>
            {submitted ? (
              <div className="toast" style={{ marginBottom: 12 }}>
                ✓ We received your enquiry. An agent will reach out shortly.
              </div>
            ) : (
              <form onSubmit={handleSubmit}>
                <input
                  required placeholder="Your name"
                  value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
                />
                <input
                  required type="tel" placeholder="Phone"
                  value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })}
                />
                <input
                  type="email" placeholder="Email (optional)"
                  value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })}
                />
                <textarea
                  rows={3} placeholder="Anything specific you'd like to know?"
                  value={form.requirement} onChange={(e) => setForm({ ...form, requirement: e.target.value })}
                />
                <button type="submit" className="btn btn-primary" disabled={submitting}>
                  <Calendar size={16} /> {submitting ? 'Sending...' : 'Send Enquiry'}
                </button>
              </form>
            )}
            <p style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 12, textAlign: 'center' }}>
              Or chat with Aria for instant help →
            </p>
          </aside>
        </div>
      </div>
    </>
  )
}
