import { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Sparkles, Search, ArrowRight, ShieldCheck, BadgeIndianRupee, Headphones } from 'lucide-react'
import { fetchFeaturedProperties } from '../services/api'
import PropertyCard from '../components/PropertyCard'

export default function Home() {
  const [featured, setFeatured] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState({ city: '', type: '', listingType: 'SALE' })
  const navigate = useNavigate()

  useEffect(() => {
    fetchFeaturedProperties()
      .then(setFeatured)
      .catch(() => setFeatured([]))
      .finally(() => setLoading(false))
  }, [])

  function handleSearch(e) {
    e.preventDefault()
    const params = new URLSearchParams()
    if (search.city) params.set('city', search.city)
    if (search.type) params.set('type', search.type)
    if (search.listingType) params.set('listingType', search.listingType)
    navigate(`/properties?${params.toString()}`)
  }

  return (
    <>
      {/* ─── Hero ───────────────────────────────────────────────── */}
      <section className="hero">
        <div className="hero-inner">
          <span className="hero-badge">
            <Sparkles size={14} /> AI-powered property search
          </span>
          <h1 className="hero-title">
            Find a home that fits<br />
            <span className="accent">your life perfectly.</span>
          </h1>
          <p className="hero-subtitle">
            Browse thousands of verified listings across India. Talk to our AI
            assistant Aria, schedule viewings instantly, and connect with trusted agents.
          </p>

          <form className="hero-search" onSubmit={handleSearch}>
            <div className="hero-search-field">
              <label>City</label>
              <input
                placeholder="Mumbai, Bangalore..."
                value={search.city}
                onChange={(e) => setSearch({ ...search, city: e.target.value })}
              />
            </div>
            <div className="hero-search-field">
              <label>Type</label>
              <select
                value={search.type}
                onChange={(e) => setSearch({ ...search, type: e.target.value })}
              >
                <option value="">Any</option>
                <option value="APARTMENT">Apartment</option>
                <option value="VILLA">Villa</option>
                <option value="INDEPENDENT_HOUSE">House</option>
                <option value="PLOT">Plot</option>
                <option value="COMMERCIAL">Commercial</option>
              </select>
            </div>
            <div className="hero-search-field">
              <label>Listing</label>
              <select
                value={search.listingType}
                onChange={(e) => setSearch({ ...search, listingType: e.target.value })}
              >
                <option value="SALE">Buy</option>
                <option value="RENT">Rent</option>
              </select>
            </div>
            <button type="submit" className="btn btn-primary">
              <Search size={16} /> Search
            </button>
          </form>

          <div className="hero-stats">
            <div>
              <div className="hero-stat-num">12,500+</div>
              <div className="hero-stat-label">Active Listings</div>
            </div>
            <div>
              <div className="hero-stat-num">8,200+</div>
              <div className="hero-stat-label">Happy Customers</div>
            </div>
            <div>
              <div className="hero-stat-num">50+</div>
              <div className="hero-stat-label">Cities Covered</div>
            </div>
            <div>
              <div className="hero-stat-num">24/7</div>
              <div className="hero-stat-label">AI Support</div>
            </div>
          </div>
        </div>
      </section>

      {/* ─── Featured properties ────────────────────────────────── */}
      <section className="section container">
        <div className="section-header">
          <div>
            <h2>Handpicked for you</h2>
            <p>Premium properties our experts recommend this week.</p>
          </div>
          <Link to="/properties" className="btn btn-ghost">
            View all <ArrowRight size={16} />
          </Link>
        </div>

        {loading ? (
          <p style={{ color: 'var(--text-muted)' }}>Loading featured properties...</p>
        ) : featured.length === 0 ? (
          <div className="empty-state">
            <h3>No featured properties yet</h3>
            <p>Check back soon — we add new listings every day.</p>
          </div>
        ) : (
          <div className="property-grid">
            {featured.map((p) => <PropertyCard key={p.id} property={p} />)}
          </div>
        )}
      </section>

      {/* ─── Why us ─────────────────────────────────────────────── */}
      <section className="section container">
        <div className="section-header">
          <div>
            <h2>Why EstateHub?</h2>
            <p>Built for buyers, sellers, and agents who want a smarter way to deal in real estate.</p>
          </div>
        </div>
        <div className="about-grid">
          <div className="about-card">
            <div className="about-card-icon"><ShieldCheck size={24} /></div>
            <h3>Verified Listings</h3>
            <p>Every property is verified by our team — no fake ads, no false promises.</p>
          </div>
          <div className="about-card">
            <div className="about-card-icon"><Sparkles size={24} /></div>
            <h3>AI Assistant Aria</h3>
            <p>Tell Aria what you want — she'll search, recommend, and book viewings instantly.</p>
          </div>
          <div className="about-card">
            <div className="about-card-icon"><BadgeIndianRupee size={24} /></div>
            <h3>Zero Brokerage</h3>
            <p>Connect directly with owners and agents. Save lakhs in unnecessary fees.</p>
          </div>
          <div className="about-card">
            <div className="about-card-icon"><Headphones size={24} /></div>
            <h3>24/7 Support</h3>
            <p>Our chatbot answers questions any time. Real agents take over when needed.</p>
          </div>
        </div>
      </section>
    </>
  )
}
