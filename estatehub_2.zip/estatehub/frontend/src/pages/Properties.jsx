import { useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { fetchProperties } from '../services/api'
import PropertyCard from '../components/PropertyCard'

export default function Properties() {
  const [searchParams, setSearchParams] = useSearchParams()
  const [filters, setFilters] = useState({
    city: searchParams.get('city') || '',
    type: searchParams.get('type') || '',
    listingType: searchParams.get('listingType') || '',
    minBedrooms: searchParams.get('minBedrooms') || '',
    maxPrice: searchParams.get('maxPrice') || '',
  })
  const [properties, setProperties] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setLoading(true)
    const params = Object.fromEntries(
      Object.entries(filters).filter(([_, v]) => v !== '' && v !== null)
    )
    fetchProperties(params)
      .then(setProperties)
      .catch(() => setProperties([]))
      .finally(() => setLoading(false))

    // Sync URL
    const sp = new URLSearchParams()
    Object.entries(params).forEach(([k, v]) => sp.set(k, v))
    setSearchParams(sp, { replace: true })
  }, [filters])

  function update(key, val) {
    setFilters((f) => ({ ...f, [key]: val }))
  }

  return (
    <div className="properties-page">
      <div style={{ marginBottom: 32 }}>
        <h1 style={{ fontSize: '2.2rem', marginBottom: 8 }}>Browse Properties</h1>
        <p style={{ color: 'var(--text-muted)' }}>
          {loading ? 'Loading...' : `${properties.length} properties available`}
        </p>
      </div>

      <div className="filter-bar">
        <div>
          <label>City</label>
          <input
            placeholder="Any"
            value={filters.city}
            onChange={(e) => update('city', e.target.value)}
          />
        </div>
        <div>
          <label>Type</label>
          <select value={filters.type} onChange={(e) => update('type', e.target.value)}>
            <option value="">Any</option>
            <option value="APARTMENT">Apartment</option>
            <option value="VILLA">Villa</option>
            <option value="INDEPENDENT_HOUSE">House</option>
            <option value="PLOT">Plot</option>
            <option value="COMMERCIAL">Commercial</option>
          </select>
        </div>
        <div>
          <label>Listing</label>
          <select value={filters.listingType} onChange={(e) => update('listingType', e.target.value)}>
            <option value="">Any</option>
            <option value="SALE">For Sale</option>
            <option value="RENT">For Rent</option>
          </select>
        </div>
        <div>
          <label>Min BHK</label>
          <select value={filters.minBedrooms} onChange={(e) => update('minBedrooms', e.target.value)}>
            <option value="">Any</option>
            <option value="1">1+</option>
            <option value="2">2+</option>
            <option value="3">3+</option>
            <option value="4">4+</option>
          </select>
        </div>
        <div>
          <label>Max Price (₹)</label>
          <input
            type="number"
            placeholder="No limit"
            value={filters.maxPrice}
            onChange={(e) => update('maxPrice', e.target.value)}
          />
        </div>
      </div>

      {loading ? (
        <p style={{ color: 'var(--text-muted)' }}>Loading...</p>
      ) : properties.length === 0 ? (
        <div className="empty-state">
          <h3>No properties match your filters</h3>
          <p>Try widening your search criteria — or chat with Aria for help.</p>
        </div>
      ) : (
        <div className="property-grid">
          {properties.map((p) => <PropertyCard key={p.id} property={p} />)}
        </div>
      )}
    </div>
  )
}
