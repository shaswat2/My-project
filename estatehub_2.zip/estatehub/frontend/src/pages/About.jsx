import { ShieldCheck, Sparkles, BadgeIndianRupee, Headphones, Users, Globe } from 'lucide-react'

export default function About() {
  return (
    <div className="about-page">
      <h1>About EstateHub</h1>
      <p>
        EstateHub is reimagining how Indians buy, sell, and rent homes. We've combined verified
        property listings, transparent pricing, and an AI assistant that actually understands
        what you need — so finding the right place feels effortless.
      </p>
      <p>
        Whether you're a first-time buyer in Pune, a family upgrading in Bangalore, or an investor
        scouting commercial space in Mumbai — our platform is built to make every step simpler.
      </p>

      <div className="about-grid">
        <div className="about-card">
          <div className="about-card-icon"><ShieldCheck size={24} /></div>
          <h3>Trust First</h3>
          <p>Every listing is verified by our ground team. No fake ads, no surprise fees.</p>
        </div>
        <div className="about-card">
          <div className="about-card-icon"><Sparkles size={24} /></div>
          <h3>AI-Powered</h3>
          <p>Aria, our chatbot, understands natural language and helps you discover, compare, and book.</p>
        </div>
        <div className="about-card">
          <div className="about-card-icon"><Users size={24} /></div>
          <h3>Real Agents</h3>
          <p>When AI isn't enough, our human agents step in — fast, knowledgeable, no pushiness.</p>
        </div>
        <div className="about-card">
          <div className="about-card-icon"><BadgeIndianRupee size={24} /></div>
          <h3>Fair Pricing</h3>
          <p>Zero brokerage on most listings. We make money when you do.</p>
        </div>
        <div className="about-card">
          <div className="about-card-icon"><Globe size={24} /></div>
          <h3>50+ Cities</h3>
          <p>Comprehensive coverage across major metros and growing tier-2 markets.</p>
        </div>
        <div className="about-card">
          <div className="about-card-icon"><Headphones size={24} /></div>
          <h3>Always On</h3>
          <p>Round-the-clock chat support — even when our offices are closed.</p>
        </div>
      </div>
    </div>
  )
}
