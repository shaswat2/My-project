import { useState } from 'react'
import { Mail, Phone, MapPin, Send } from 'lucide-react'
import { submitLead } from '../services/api'

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', phone: '', requirement: '' })
  const [done, setDone] = useState(false)
  const [submitting, setSubmitting] = useState(false)

  async function submit(e) {
    e.preventDefault()
    setSubmitting(true)
    try {
      await submitLead({ ...form, source: 'contact-form' })
      setDone(true)
      setForm({ name: '', email: '', phone: '', requirement: '' })
    } catch {
      alert('Could not submit. Please try again.')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="contact-page">
      <h1>Get in touch</h1>
      <p style={{ color: 'var(--text-muted)', marginBottom: 32, fontSize: 17 }}>
        Have a question, want to list a property, or just need a hand finding a home? Drop us a line.
      </p>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 32, marginBottom: 32 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <Mail size={20} color="var(--primary)" />
          <span>hello@estatehub.com</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <Phone size={20} color="var(--primary)" />
          <span>+91 98765 43210</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, gridColumn: '1 / -1' }}>
          <MapPin size={20} color="var(--primary)" />
          <span>Bangalore, India</span>
        </div>
      </div>

      {done && <div className="toast" style={{ marginBottom: 16 }}>✓ Thanks! We'll be in touch soon.</div>}

      <form className="contact-form" onSubmit={submit}>
        <input required placeholder="Full name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        <input required type="tel" placeholder="Phone number" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
        <input type="email" placeholder="Email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
        <textarea required placeholder="How can we help?" value={form.requirement} onChange={(e) => setForm({ ...form, requirement: e.target.value })} />
        <button type="submit" className="btn btn-primary" disabled={submitting}>
          <Send size={16} /> {submitting ? 'Sending...' : 'Send Message'}
        </button>
      </form>
    </div>
  )
}
